<?php
/*
Plugin Name: wpDiary
Plugin URI: http://blog.tcrouzet.com/plugin-wordpress-diaryplugin-wordpress-diary/
Description: On-demand Word-XML export of your WordPress database. Use Diary command in Manage menu.
Author: Thierry Crouzet
Version: 1.0
Author URI: http://blog.tcrouzet.com/
*/

// CHANGE THIS IF YOU WANT TO USE A 
// DIFFERENT BACKUP LOCATION
define('WP_RTF_DIR', 'wp-content/backup');
define('WP_DIARY_TABLE', 'wp_diary');
ini_set("display_errors","1");
ini_set("memory_limit","512M");

class wpdiary{

	private $rtf_complete = false;
	private $rtf_file = '';
	private $rtf_dir = WP_RTF_DIR;
	private $rtf_errors = array();
	private $limit_comdate = "";
	private $onlyauthor=false;
	private $noimage=false;
	private $author="";
	private $comnumber=0;

	function gzip() {
		return false;
		return function_exists('gzopen');
	}


	function __construct(){
		global $wpdb;
		$this->rtf_dir = trailingslashit($this->rtf_dir);
		$this->basename = preg_replace('/^.*wp-content[\\\\\/]plugins[\\\\\/]/', '', __FILE__);
		
		//The first time create WP_DIARY_TABLE
		if(!$this->table_exists(WP_DIARY_TABLE)){
			//status 0 (publi�) 1 (pas de commentaire) 2 (hide)
			$query="CREATE TABLE `".WP_DIARY_TABLE."` (`diary_post` int(11) NOT NULL,`diary_status` tinyint(4) NOT NULL default '2',PRIMARY KEY  (`diary_post`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
			$newtable= $wpdb->query($query);
		}
		if(!$this->table_exists(WP_DIARY_TABLE.'com')){
			//status 0 (publi�) 1 (hide)
			$query="CREATE TABLE `".WP_DIARY_TABLE."com` (`diary_com` int(11) NOT NULL,`diary_comstatus` tinyint(4) NOT NULL default '1',PRIMARY KEY  (`diary_com`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
			$newtable= $wpdb->query($query);
		}
		
		if(isset($_POST['do_onlyauthor'])&&$_POST['do_onlyauthor']==1){
			$this->onlyauthor=true;
			$this->author=$_POST['do_author'];
		}

		if(isset($_POST['do_noimage'])&&$_POST['do_noimage']==1){
			$this->noimage=true;
		}
		
//		$this->dump($_POST);
		
		if(!empty($_POST['do_post'])){
			$query="INSERT LOW_PRIORITY INTO ".WP_DIARY_TABLE." SET diary_post='".$_POST['do_post']."',diary_status='2' ON DUPLICATE KEY UPDATE diary_status=MOD(diary_status+1,3)";
			$wpdb->query($query);
		}elseif(!empty($_POST['do_com'])){
			$query="INSERT LOW_PRIORITY INTO ".WP_DIARY_TABLE." SET diary_post='".$_POST['do_com']."',diary_status='1' ON DUPLICATE KEY UPDATE diary_status=MOD(diary_status+1,2)";
			$wpdb->query($query);
		}elseif(!empty($_POST['do_delcom'])){
			list($_POST['do_listcom'],$_POST['do_delcom'])=explode("_",$_POST['do_delcom']);			
			$query="INSERT LOW_PRIORITY INTO ".WP_DIARY_TABLE."com SET diary_com='".$_POST['do_delcom']."',diary_comstatus='1' ON DUPLICATE KEY UPDATE diary_comstatus=MOD(diary_comstatus+1,2)";
			$wpdb->query($query);
		}elseif(isset($_POST['do_rtf'])) {

			if ( !current_user_can('import') ) die(__('You are not allowed to perform backups.'));

			if(isset($_POST['do_comdate'])&&!empty($_POST['do_comdate']))
				$this->limit_comdate=$_POST['do_comdate'];
			
			//Start backup
			$this->perform_backup();
		}
		add_action('admin_menu', array(&$this, 'admin_menu'));

	}

	function table_exists($table){
		global $wpdb;
		$query="show tables like '$table'";
		if($wpdb->query($query)==1) return true; else return false;
	}
	
	function make_query(){
		global $wpdb;
		$query="SELECT * FROM $wpdb->posts LEFT JOIN ".WP_DIARY_TABLE." ON ID=diary_post WHERE post_status='publish'";
//		$query.=" AND ID='321'";return $query;			//test on a single post
		if(isset($_POST['do_year'])&&$_POST['do_year']!="all"){
			$query.=" AND post_date LIKE '".$_POST['do_year']."%'";
		}
		$query.=" ORDER BY post_date_gmt ASC";
		return $query;
	}

	function perform_backup(){
		global $wpdb;
		$posts = $wpdb->get_results($this->make_query());
		$this->backup_complete = false;
		if(!$posts){
			$this->backup_error(__('Could not perform '.$query));
			$this->fatal_error = __('Could not perform '.$query);
			return;
		}
		if(!is_writable(ABSPATH . $this->rtf_dir)) {
			$this->backup_error(__('Could not open the backup file for writing!'));
			$this->fatal_error = __('The backup file could not be saved.  Please check the permissions for writing to your backup directory and try again.');
			return;
		}
		$this->rtf_file = $this->rtf_dir.date('Y-m-d').".doc";
		$this->fp = $this->open(ABSPATH . $this->rtf_file, 'w');
		if(!$this->fp) {
			$this->backup_error(__('Could not open the backup file for writing!'));
			$this->fatal_error = __('The backup file could not be saved.  Please check the permissions for writing to your backup directory and try again.');
			return;
		}

		$this->stow($this->loadHeader());
		$limit=0;
		$year=0;
		$month="";
		$nbillets=0;		//Number of exported posts
		$nbilletstotal=0;	//Total number of posts
		$ncom=0;		//Number of comments
		$ncomauthor=0;	//Number of author comments
		$this->stow('<wx:sub-section>');
		foreach($posts as $post){
			//Date
			$nbilletstotal++;
			if($post->diary_status==2) continue;
//			$this->dump($post);
			$tmpstp=strtotime($post->post_date);
			$newyear=date("Y",$tmpstp);
			if($newyear!=$year&&empty($_POST['do_year'])){
				//New year
				$this->title1($newyear);
				$this->endSection("","");
				$year=$newyear;
			}
			$newmonth=date("F",$tmpstp);
			if($newmonth!=$month){
				//New month
				if(!empty($month)) $this->endSection($this->traducDate($month),$newyear);
				$msg=$this->traducDate($newmonth);
//				if(!empty($month)) $msg='<w:br w:type="page"/>'.$msg;
				$this->title2($msg);
				$month=$newmonth;
			}
			//Post
			$nbillets++;
			$titre=$post->post_title.'</w:t></w:r><w:r><w:tab/><w:t>'.$this->traducdate(date("l",$tmpstp)).' ';
			$j=date("j",$tmpstp);
			if($j=='1') $titre.='1</w:t></w:r><w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:t>er'; else $titre.=$j;
			$this->title3($titre);
			$this->text($post->post_content);
			
			//Comments
			$wherecom="comment_post_ID='$post->ID'";
			$ncomments = $wpdb->get_results("SELECT count(*) AS ncom FROM $wpdb->comments WHERE $wherecom");
			$ncom+=$ncomments[0]->ncom;
			if($this->onlyauthor) $wherecom.=" AND comment_author='$this->author'";
			$ncomments = $wpdb->get_results("SELECT count(*) AS ncom FROM $wpdb->comments WHERE $wherecom");
			$ncomauthor+=$ncomments[0]->ncom;
			if($post->diary_status==1) continue;
			$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments LEFT JOIN ".WP_DIARY_TABLE."com ON comment_ID=diary_com WHERE $wherecom ORDER BY comment_date");
			if($tmpstp<strtotime($this->limit_comdate)) $comments=false;
			if($comments){
				$this->comnumber=0;
				foreach($comments as $c){
					if(!empty($c->diary_com)&&$c->diary_comstatus==1) continue; 
					$this->comnumber++;
					$this->comment($c->comment_author,$c->comment_content);
				}
			}
//			if($limit==0) break;
			$limit++;			
		}
		//Last page
		$this->endSection($this->traducDate($month),$newyear,1);
		if($this->onlyauthor) $ncom=$ncom-$ncomauthor;
		$msg=$nbillets.' billets imprim�s sur un total de '.$nbilletstotal.'<br />'.$ncom.' commentaires de lecteurs<br />'.$ncomauthor.' commentaires de l\'auteur<br />imprim� le '.$this->traducdate(date("j F Y"));
		$this->text($msg);
		//Close file
		$this->endSection("","",2);
		$this->footer();
		$this->close($this->fp);
		$this->backup_complete=true;
	}

	///////////////////////////////
	function admin_menu() {
		add_management_page(__('Diary'), __('Diary'), 'import', basename(__FILE__), array(&$this, 'rtf_menu'));
	}

	/////////////
	function open($filename = '', $mode = 'w') {
		if ('' == $filename) return false;
		if ($this->gzip()) {
			$fp = @gzopen($filename, $mode);
		} else {
			$fp = @fopen($filename, $mode);
		}
		return $fp;
	}

	//////////////
	function close($fp) {
		if ($this->gzip()) {
			gzclose($fp);
		} else {
			fclose($fp);
		}
	}
	
	//////////////
	function stow($query_line) {
		$query_line.="\n";
		if ($this->gzip()) {
			if(@gzwrite($this->fp, $query_line) === FALSE) {
				backup_error(__('There was an error writing a line to the backup script:'));
				backup_error('&nbsp;&nbsp;' . $query_line);
			}
		} else {
			if(@fwrite($this->fp, $query_line) === FALSE) {
				backup_error(__('There was an error writing a line to the backup script:'));
				backup_error('&nbsp;&nbsp;' . $query_line);
			}
		}
	}

	function seems_utf8($Str){
		for ($i=0; $i<strlen($Str); $i++) {
			if (ord($Str[$i]) < 0x80) continue; # 0bbbbbbb
			elseif ((ord($Str[$i]) & 0xE0) == 0xC0) $n=1; # 110bbbbb
			elseif ((ord($Str[$i]) & 0xF0) == 0xE0) $n=2; # 1110bbbb
			elseif ((ord($Str[$i]) & 0xF8) == 0xF0) $n=3; # 11110bbb
			elseif ((ord($Str[$i]) & 0xFC) == 0xF8) $n=4; # 111110bb
			elseif ((ord($Str[$i]) & 0xFE) == 0xFC) $n=5; # 1111110b
			else return false; # Does not match any model
			for ($j=0; $j<$n; $j++) { # n bytes matching 10bbbbbb follow ?
			if ((++$i == strlen($Str)) || ((ord($Str[$i]) & 0xC0) != 0x80))
				return false;
	  		}
	 	}
		return true;
	}

	// Traduction date
	function traducDate($content) {
		$dateUS=array('January','February','March','April','May','June','July','August','September','October','November','December','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
		$dateFR=array('janvier','f�vrier','mars','avril','mai','juin','juillet','ao�t','septembre','octobre','novembre','d�cembre','lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche');
		return str_replace($dateUS,$dateFR,$content);
	}

	function mb_chr($num){
		if($num<128)
		return chr($num);
		
		if($num<2048)
		return 
		chr(192+($num>>6)).
		chr(128+($num&63));
		
		if($num<65536)
		return
		chr(224+($num>>12)).
		chr(128+(($num>>6)&63)).
		chr(128+($num&63));
		
		if($num<196607)
		return
		chr(240+($num>>18)).
		chr(128+(($num>>12)&4095)).
		chr(128+(($num>>6)&63)).
		chr(128+($num&63));
		
		return false;
	}

	function format($msg) {
		//Special caracters
		$msg=str_replace(array("&#233;","&eacute;"),utf8_encode('�'),$msg);
		$msg=str_replace("&#244;",utf8_encode('�'),$msg);
		$msg=str_replace("&#234;",utf8_encode('�'),$msg);
		$msg=str_replace("&#232;",utf8_encode('�'),$msg);
		$msg=str_replace("&#224;",utf8_encode('�'),$msg);
		$msg=str_replace("&#226;",utf8_encode('�'),$msg); 
		$msg=str_replace("&#192;",utf8_encode('�'),$msg); 
		$msg=str_replace(array("&raquo;","&#171;"),utf8_encode('�'),$msg);
		$msg=str_replace("&nbsp;",utf8_encode(chr(160)),$msg);
		$msg=str_replace(array("&laquo;","&#171;"),utf8_encode('�'),$msg);
		$msg=str_replace("&quot;",utf8_encode('"'),$msg);
		$msg=str_replace("","",$msg);
		$msg=preg_replace("/<p\s(.*?)>/si","",$msg);
		$msg=str_replace("XIX<sup>e</sup>",$this->century("xix","e"),$msg);
		$msg=str_replace("XX<sup>e</sup>",$this->century("xx","e"),$msg);
		$msg=str_replace("XXI<sup>e</sup>",$this->century("xxi","e"),$msg);
		$msg=$this->ital($msg);
		$msg=$this->bold($msg);
		$msg=$this->sup($msg);
		$msg=$this->sub($msg);
		$msg=$this->squizeImg($msg);
		$msg=$this->linksParser($msg);
		$msg=$this->hardspace($msg);
		//Delete all other tags except XML
		$msg=preg_replace("!<[^w:|^/w:].*?>!si","",$msg);
		$msg=preg_replace("!</[^w:].*?>!si","",$msg);
		$msg=str_replace("&","&amp;",$msg);
		$msg=str_replace("'",$this->mb_chr(8217),$msg);
		if(!seems_utf8($msg)) $msg=utf8_encode($msg);
		if($msg==utf8_encode(chr(160))) $msg="";
		return trim($msg);
	}

	function century($date,$exp){
		return '</w:t></w:r><w:r><w:rPr><w:smallCaps/></w:rPr><w:t>'.$date.'</w:t></w:r><w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:t>'.$exp.'</w:t></w:r><w:r><w:t>';
	}

	function sup($msg){
		$msg=str_replace('<sup>','</w:t></w:r><w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:t>',$msg);
		$msg=str_replace('</sup>','</w:t></w:r><w:r><w:t>',$msg);
		return $msg;
	}

	function sub($msg){
		$msg=str_replace('<sub>','</w:t></w:r><w:r><w:rPr><w:vertAlign w:val="subscript"/></w:rPr><w:t>',$msg);
		$msg=str_replace('</sub>','</w:t></w:r><w:r><w:t>',$msg);
		return $msg;
	}
	
	function linksParser($msg){
		$thiss->links=array();
		$regexp="<a\s[^>]*href\s*=\s*([\"\']??)(http|https)\:\/\/([^\" >]*?)\\1[^>]*>(.*)<\/a>";
		if(preg_match_all("/$regexp/siU",$msg,$matches,PREG_SET_ORDER)){
			foreach($matches as $match){
				if(eregi("<img",$match[4]))
					$msg=str_replace($match[0],"",$msg);
				else{
//					$msg=str_replace($match[0],"</w:t></w:r><w:r><w:rPr><w:rStyle w:val=\"link\"/></w:rPr><w:t>".$match[4]."</w:t></w:r><w:r><w:t>",$msg);
					$msg=str_replace($match[0],"</w:t></w:r><w:r><w:rPr><w:sz-cs w:val=\"26\"/><w:u w:val=\"single\"/></w:rPr><w:t>".$match[4]."</w:t></w:r><w:r><w:t>",$msg);					
				}
				$thiss->links[]=$match[3];
			}
		}
		$thiss->links=array_unique($thiss->links);
		return $msg;
	}

	function hardspace($msg) {
		$msg=ereg_replace(" \?",utf8_encode(chr(160))."?",$msg);
		$msg=ereg_replace(" \!",utf8_encode(chr(160))."!",$msg);
		$msg=ereg_replace(" \;",utf8_encode(chr(160)).";",$msg);
		$msg=ereg_replace(" \:",utf8_encode(chr(160)).":",$msg);
		$msg=ereg_replace(" \%",utf8_encode(chr(160))."%",$msg);
		$msg=ereg_replace(" 0",utf8_encode(chr(160))."0",$msg);
		$msg=ereg_replace("� ","�".utf8_encode(chr(160)),$msg);
		$msg=ereg_replace(" ".$this->mb_chr(187),utf8_encode(chr(160)).$this->mb_chr(187),$msg);
		$msg=ereg_replace("-- ",$this->mb_chr(8212).utf8_encode(chr(160)),$msg); 
		return $msg;
	}

	function squizeImg($msg) {
		$msg=preg_replace("/<img (.*)>/siU","",$msg);
		return trim($msg);
	}

	function ital($msg) {
//		$msg=str_replace('<em>','</w:t></w:r><w:r><w:rPr><w:rStyle w:val="ital"/></w:rPr><w:t>',$msg);
		$msg=str_replace('<em>','</w:t></w:r><w:r><w:rPr><w:i/></w:rPr><w:t>',$msg);
		$msg=str_replace('</em>','</w:t></w:r><w:r><w:t>',$msg);
		return $msg;
	}

	function bold($msg) {
//		$msg=str_replace(array('<b>','<strong>','<h2>'),'</w:t></w:r><w:r><w:rPr><w:rStyle w:val="bold"/></w:rPr><w:t>',$msg);
		$msg=str_replace(array('<b>','<strong>','<h2>'),'</w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>',$msg);
		$msg=str_replace(array('</b>','</strong>','</h2>'),'</w:t></w:r><w:r><w:t>',$msg);
		return $msg;
	}

	function listing($msg_org){
		$msg=str_replace('<ol>','<ul>',$msg_org);
		$msg=str_replace(array('</ol>','</ul>','</li>'),'',$msg);
		if($msg==$msg_org) return $msg_org;
		$lists=explode("<ul>",$msg);
		$out="";
		foreach($lists as $list){
			$list=trim($list);
			if(empty($list)) continue;
			$lis=explode("<li>",$list);
			if(count($lis)==1)
				//No list
				$out.=$list;
			else{
				$i=1;
				foreach($lis as $li){
					if(empty($li)) continue;
					$out.="\n".$i."/".utf8_encode(chr(160)).$li;
					$i++;
				}
				$out.="\n";
			}
		}
		return $out;
	}

	function blockquote($msg){
		if(!eregi("<blockquote>",$msg)) return $msg;
		$out="";
		$quotes=explode("<blockquote>",$msg);
		foreach($quotes as $quote){
			if(!eregi("</blockquote>",$quote)){
				$out.=$quote;
				continue;
			}
			$pars=explode("</blockquote>",$quote);
			$pars[0]=str_replace("\n","</w:t></w:r><w:r><w:br/><w:t>",$pars[0]);
			$out.="<w:p><w:pPr><w:pStyle w:val=\"blockquote\"/></w:pPr><w:r><w:t>".$pars[0];
			if(isset($pars[1])) $out.=$pars[1];
		}
		return $out;
	}

	function h3($msg){
		if(!eregi("<h3>",$msg)) return $msg;
		$out="";
		$quotes=explode("<h3>",$msg);
		foreach($quotes as $quote){
			if(!eregi("</h3>",$quote)){
				$out.=$quote;
				continue;
			}
			$pars=explode("</h3>",$quote);
			$pars[0]=str_replace("\n","</w:t></w:r><w:r><w:br/><w:t>",$pars[0]);
			$out.="<w:p><w:pPr><w:pStyle w:val=\"Titre4\"/></w:pPr><w:r><w:t>".$pars[0];
			if(isset($pars[1])) $out.=$pars[1];
		}
		return $out;
	}

	function img1($msg){
		if(!eregi("<img",$msg)) return $msg;
		$msg=preg_replace("!<img(.*?)src=\"(.*?)\"(.*?)>!si","[start:img]\\2[stop:img]\n",$msg);
		return $msg;
	}

	function img2($msg){
//		return $msg;
		if(strpos($msg,"[start:img]")===false) return $msg;
		if(strpos($msg,"[stop:img]")===false) return $msg;
		list(,$url)=explode("[start:img]",$msg);
		list($url)=explode("[stop:img]",$url);
		if(!strpos($url,"http://")===0){
			$msg=str_replace($url,"http://blog.tcrouzet.com".$url,$msg);
			$url="http://blog.tcrouzet.com".$url;
		}
		$size=$this->imagesize($url);
		if($size->x>0 && $size->y>0){
			$size->x=floor($size->x*0.75);
			$size->y=floor($size->y*0.75);
			$size="width:".$size->x."px;height:".$size->y."px";
		}else{
			//Not find
			return "";
//			$size="width:300px;height:100px";
		}
		$msg=str_replace('[start:img]','<w:p><w:pPr><w:pStyle w:val="image"/></w:pPr><w:r><w:pict><v:shape style="'.$size.'"><v:imagedata src="',$msg);
		$msg=str_replace('[stop:img]','"/></v:shape></w:pict>',$msg);
		$msg=str_replace('<w:p><w:r><w:t><w:p><w:pPr><w:pStyle w:val="image"/>','<w:p><w:pPr><w:pStyle w:val="image"/>',$msg);
		$msg=str_replace('</w:pict></w:t>','</w:pict>',$msg);
		$msg=str_replace('<w:p><w:r><w:rPr><w:i/></w:rPr><w:t><w:p><w:pPr><w:pStyle w:val="image"/>','<w:p><w:pPr><w:pStyle w:val="image"/>',$msg);
		return $msg;
	}

	/** Retourne taille */
	function imagesize($sourcefile){
		try{
			$tmp=@getimagesize($sourcefile,$info);
		}catch(Exception $e) {
			return false;
		}
		$picsize->x=$tmp[0];
		$picsize->y=$tmp[1];
		$picsize->type=$tmp[2];		//Extension
		$picsize->html=$tmp[3];
		$picsize->mime=$tmp['mime'];		
		if(isset($tmp['bits'])) $picsize->bits=$tmp['bits']; else $picsize->bits=8;
		if($picsize->bits<8) $picsize->bits=8;  
		return $picsize;
	}
	
	function backup_error($err) {
		if(count($this->backup_errors) < 20) {
			$this->backup_errors[] = $err;
		} elseif(count($this->backup_errors) == 20) {
			$this->backup_errors[] = __('Subsequent errors have been omitted from this log.');
		}
	}

	function loadHeader(){
		$filelocation=ABSPATH.'wp-content/plugins/wpdiary/header.xml';
		if(@file_exists($filelocation)){
			$file_content=file_get_contents($filelocation);
			return $file_content;
		}else{
			return "";
		}
	}

	function loadfooter(){
		$filelocation=ABSPATH.'wp-content/plugins/wpdiary/footer.xml';
		if(@file_exists($filelocation)){
			$file_content=file_get_contents($filelocation);
			return $file_content;
		}else{
			return "";
		}
	}

	function comment($author,$msg){
		$msg=str_replace("</p>","\n",$msg);
		$msg=str_replace("<br />","\n",$msg);
		$msg=$this->listing($msg);
		$pars=explode("\n",$msg);
		if($author==$this->author){
			$pars[0]="COM".$this->comnumber.". ".$pars[0];
		}else{
			$pars[0]="<b>$author</b> ".$pars[0];
		}
		foreach($pars as $par){
			$par=trim($par);
			if(empty($par)) continue;
			$par=$this->format($par);
			if(empty($par)) continue;
			$this->stow('<w:p><w:pPr><w:pStyle w:val="Comment"/></w:pPr><w:r><w:t>'.$par.'</w:t></w:r></w:p>');
		}
	}

	function title1($msg){
		$this->stow('<w:p><w:pPr><w:pStyle w:val="Titre1"/></w:pPr><w:r><w:t>'.$this->format($msg).'</w:t></w:r></w:p>');
	}

	function title2($msg){
		$this->stow('<w:p><w:pPr><w:pStyle w:val="Titre2"/></w:pPr><w:r><w:t>'.$this->format($msg).'</w:t></w:r></w:p>');
	}

	function title3($msg){
		$this->stow('<w:p><w:pPr><w:pStyle w:val="Titre3"/></w:pPr><w:r><w:t>'.$this->format($msg).'</w:t></w:r></w:p>');
	}

	function title4($msg){
		$this->stow('<w:p><w:pPr><w:pStyle w:val="Titre4"/></w:pPr><w:r><w:t>'.$this->format($msg).'</w:t></w:r></w:p>');
	}

	function text($msg){
		//Delete PHP code
		$msg=preg_replace("/<\?php(.*)\?>/si","",$msg);
		//Mark lines
		$msg=str_replace("</p>","\n",$msg);
		$msg=str_replace("<br />","\n",$msg);
		$msg=$this->listing($msg);
		$msg=$this->blockquote($msg);
		$msg=$this->h3($msg);
		if(!$this->noimage) $msg=$this->img1($msg);
		$pars=explode("\n",$msg);
		foreach($pars as $par){
			$par=trim($par);
			if(empty($par)) continue;
			$par=$this->format($par);
			$par=str_replace('</w:t></w:r><w:r><w:rPr><w:sz-cs w:val="26"/><w:u w:val="single"/></w:rPr><w:t></w:t></w:r><w:r><w:t>','',$par);
			if(empty($par)) continue;
			$par='<w:p><w:r><w:t>'.$par.'</w:t></w:r></w:p>';
			$par=str_replace("<w:t></w:t>","",$par);
			$par=str_replace("<w:r></w:r>","",$par);
			$par=str_replace('<w:p><w:r><w:t><w:p><w:pPr><w:pStyle w:val="blockquote"/>','<w:p><w:pPr><w:pStyle w:val="blockquote"/>',$par);
			$par=str_replace('<w:p><w:r><w:t><w:p><w:pPr><w:pStyle w:val="Titre4"/>','<w:p><w:pPr><w:pStyle w:val="Titre4"/>',$par);
			if(!$this->noimage) $par=$this->img2($par);
			$this->stow($par);
		}
	}

	function endSection($month,$year,$last=0){
		if($last<2) $this->stow('<w:p><w:pPr>');
		$this->stow('<w:sectPr>');
		$this->stow('<w:hdr w:type="even"><w:p><w:pPr><w:pStyle w:val="Folio"/></w:pPr><w:fldSimple w:instr=" PAGE   \* MERGEFORMAT "><w:r><w:rPr><w:noProof/></w:rPr><w:t>2</w:t></w:r></w:fldSimple><w:r><w:tab/><w:t>'.$this->format($month).'</w:t></w:r></w:p></w:hdr>');
		$this->stow('<w:hdr w:type="odd"><w:p><w:pPr><w:pStyle w:val="Folio"/></w:pPr><w:r><w:t>'.$year.'</w:t></w:r><w:r><w:tab/></w:r><w:fldSimple w:instr=" PAGE   \* MERGEFORMAT "><w:r><w:rPr><w:noProof/></w:rPr><w:t>3</w:t></w:r></w:fldSimple></w:p></w:hdr>');
		$this->stow('<w:pgSz w:w="9001" w:h="13322" w:code="28"/><w:pgMar w:top="1247" w:right="1247" w:bottom="1134" w:left="1418" w:header="600" w:footer="0" w:gutter="0"/><w:cols w:space="708"/><w:titlePg/><w:docGrid w:line-pitch="360"/>');
		$this->stow('</w:sectPr>');
		if($last<2){
			$this->stow('</w:pPr></w:p>');
			$this->stow('</wx:sub-section>');
		}
		if($last==0) $this->stow('<wx:sub-section>');
	}
	
	function footer(){
		$this->stow('</w:body></w:wordDocument>');
	}

	////////////////////////////
	function rtf_menu() {
		global $wpdb;
		$feedback = '';
		$WHOOPS = FALSE;
		
		// did we just do a backup?  If so, let's report the status
		if($this->backup_complete ){
			$feedback = '<div class="updated"><p>' . __('Diary backup Successful') . '!';
			$file = $this->rtf_file;
			$feedback .= '<br />' . __('Your RTF backup file has been saved on the server at '.date('H:i \t\h\e Y-m-d').'. If you would like to download it now, right click and select "Save As"');
			$feedback .= ':<br /> <a href="' . get_settings('siteurl') . "/$file\">$file</a> : " . sprintf(__('%s bytes'), filesize(ABSPATH . $file));
			$feedback .= '</p></div>';
		}
		
		if (count($this->backup_errors)) {
			$feedback .= '<div class="updated error">' . __('The following errors were reported:') . "<pre>";
			foreach($this->backup_errors as $error) {
				$feedback .= "{$error}\n";  //Errors are already localized
			}
			$feedback .= "</pre></div>";
		}
	
		if (!empty($feedback)) echo $feedback;

		// Give the new dirs the same perms as wp-content.
		$stat = stat( ABSPATH . 'wp-content' );
		$dir_perms = $stat['mode'] & 0000777; // Get the permission bits.

		if ( !file_exists( ABSPATH . $this->rtf_dir) ) {
			if ( @ mkdir( ABSPATH . $this->rtf_dir) ) {
				@ chmod( ABSPATH . $this->rtf_dir, $dir_perms);
			} else {
				echo '<div class="updated error"><p align="center">' . __('WARNING: Your wp-content directory is <strong>NOT</strong> writable! We can not create the backup directory.') . '<br />' . ABSPATH . $this->rtf_dir . "</p></div>";
			$WHOOPS = TRUE;
			}
		}
		
		if ( !is_writable( ABSPATH . $this->rtf_dir) ) {
			echo '<div class="updated error"><p align="center">' . __('WARNING: Your backup directory is <strong>NOT</strong> writable! We can not create the backup directory.') . '<br />' . ABSPATH . "</p></div>";
		}

		if ( !file_exists( ABSPATH . $this->rtf_dir . 'index.php') ) {
			@ touch( ABSPATH . $this->rtf_dir . "index.php");
		}

		echo "<div class='wrap'>";
		echo '<h2>' . __('WpDiary') . '</h2>';
		echo 'Backup to Microsoft Word format by <a href="http://tcrouzet.com">Thierry Crouzet</a>. Ready for lulu.com printing in 6 x 9 format.';
		echo '<form method="post">';		
		if(!$WHOOPS){
			if($this->limit_comdate=="0") $this->limit_comdate=date("d-m-Y");
			echo '<input type="hidden" name="do_rtf" id="do_rtf" value="rtf" /><br />';
			echo 'Data to export <select name="do_year"><option value="">All years';
			$selected=false;
			for($i=2002;$i<=date('Y');$i++){
				if(isset($_POST['do_year']) && $_POST['do_year']==$i){
					$selected=true;
					echo '<option value="'.$i.'" selected>'.$i;
				}elseif(date('Y')==$i && !$selected)
					echo '<option value="'.$i.'" selected>'.$i;
				else{
					echo '<option value="'.$i.'">'.$i;
				}
			}
			echo '</select><br /><br />';
			
			//Find admin
			$admin="";
			$query="SELECT user_email,display_name FROM ".$wpdb->users." WHERE user_login='admin' LIMIT 1";
			$admin=$wpdb->get_results($query);
			if($admin){
				$admin=$admin[0]->display_name;
			}			
			
			echo '<input type="checkbox" name="do_noimage" value="1"/> No picture<br />';
			echo '<input type="checkbox" name="do_onlyauthor" value="1" checked /> Only export comments of <input type="text" value="'.$admin.'" name="do_author" ><br />';
			echo 'Export comments only after day-month-year (empty if no comments) <input type="text" name="do_comdate" value="'.$this->limit_comdate.'" /><br />';
			echo '<p class="submit"><input type="submit" name="submit" onclick="document.getElementById(\'do_rtf\').value=\'do_rtf\';" value="' . __('Start backup') . '!" / ></p>';
		} else {
			echo '<p class="alternate">' . __('WARNING: Your backup directory is <strong>NOT</strong> writable!') . '</p>';
		}
		echo '</form>';
		
		//Post selection
		$posts=$wpdb->get_results($this->make_query());
		if($posts){
			echo '<form method="post">';
			echo '<input type="hidden" name="do_post" id="do_post" value="" />'."\n";
			echo '<input type="hidden" name="do_com" id="do_com" value="" />'."\n";
			echo '<input type="hidden" name="do_listcom" id="do_listcom" value="" />'."\n";
			echo '<input type="hidden" name="do_delcom" id="do_delcom" value="" />'."\n";
			if($this->onlyauthor){
				echo '<input type="hidden" name="do_onlyauthor" value="1" />'."\n";
				echo '<input type="hidden" value="'.$admin.'" name="do_author" >'."\n";
			}
			if(isset($_POST['do_year'])&&$_POST['do_year']!="all"){
				echo '<input type="hidden" name="do_year" id="do_year" value="'.$_POST['do_year'].'" />'."\n";
			}			
			$month="";
			$back="FFF";
			echo '<table>';
			foreach($posts as $post){
				$tmpstp=strtotime($post->post_date);
				$newmonth=date("F Y",$tmpstp);
				if($newmonth!=$month){
					//New month
					echo "<tr><td clospan=2><h4>$newmonth</h4></td>";
					$month=$newmonth;
				}
				if($post->diary_status==2) {$value='Export';$value2='Comment';$style=" style='color:gray'";}		//Not exported
				elseif($post->diary_status==1) {$value='NoExport';$value2='Comment';$style="";}						//Exported without comments
				else {$value='NoExport';$value2='NoComment';$style="";}												//Exported with comments
				if($post->ID==$_POST['do_post'] || $post->ID==$_POST['do_com']) $back="FFD700";						//Hightlight last modification
				echo '<tr style="background:#'.$back.'">';
				echo '<td><a name="'.$post->ID.'"></a><a href="/?p='.$post->ID.'" target="_blank"'.$style.'>'.$post->post_title.'</a></td>';
				echo '<td><input type="submit" name="submit" onclick="document.getElementById(\'do_post\').value=\''.$post->ID.'\';" value="'.$value.'" /></td>';
				echo '<td><input type="submit" name="submit" onclick="document.getElementById(\'do_com\').value=\''.$post->ID.'\';" value="'.$value2.'" /></td>';
				echo '<td><input type="submit" name="submit" onclick="document.getElementById(\'do_listcom\').value=\''.$post->ID.'\';" value="List comments" /></td>';
				echo "\n</tr>";
				if($back=="FFF") $back="EEE"; else $back="FFF";
				
				//List comments
				if($post->ID==$_POST['do_listcom']){
					echo '<tr><td colspan="4">';
					$wherecom="comment_post_ID='$post->ID'";
					if($this->onlyauthor) $wherecom.=" AND comment_author='$this->author'";
					$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments LEFT JOIN ".WP_DIARY_TABLE."com ON comment_ID=diary_com WHERE $wherecom ORDER BY comment_date");
					if($comments){
						foreach($comments as $c){
							if(!empty($c->diary_com)&&$c->diary_comstatus==1) echo '<span style="color:#ccc">';
							echo $c->comment_content.'<br/>';
							if(!empty($c->diary_com)&&$c->diary_comstatus==1) echo '</span>';
							echo '<input type="submit" name="submit" onclick="document.getElementById(\'do_delcom\').value=\''.$post->ID."_".$c->comment_ID.'\';" value="';
							if(!empty($c->diary_com)&&$c->diary_comstatus==1) echo 'Restaure'; else echo 'Remove';  
							echo '" />';
							echo '<br/><br/>';
						}
					}
					echo '</td></tr>'; 
				}
			}
			echo '</table></form>';
			
			//Go to last modification
			if(!empty($_POST['do_post'])){
				echo "\n".'<script type="text/javascript"><!--'."\n".'location.href=location+"#'.$_POST['do_post'].'";'."\n".'--></script>';
			}
			if(!empty($_POST['do_com'])){
				echo "\n".'<script type="text/javascript"><!--'."\n".'location.href=location+"#'.$_POST['do_com'].'";'."\n".'--></script>';
			}
			if(!empty($_POST['do_listcom'])){
				echo "\n".'<script type="text/javascript"><!--'."\n".'location.href=location+"#'.$_POST['do_listcom'].'";'."\n".'--></script>';
			}
			
		}
				
		echo '</div>';
		
	}// end wp_rtf_menu()

	function dump($obj){
		echo("<pre>");
		var_dump($obj);
		echo("</pre>");
	}

}

function wpdiary_init() {
	global $mywprtfbackup;
	if(!current_user_can('import')) return;
	$mywprtfbackup = new wpdiary(); 	
}

add_action('plugins_loaded','wpdiary_init');

?>
