=== wpDiary ===
Contributor: tcrouzet
Donate link: http://blog.tcrouzet.com
Tags: post,google,seo,meta,meta keywords,meta description,title,posts,plugin
Requires at least: 2.0
Tested up to: 2.6
Stable tag: trunk

On-demand Word-XML export of your WordPress database. Use Diary command in Manage menu.

== Description ==

On-demand ***Word***-XML export of your WordPress database. Use Diary command in Manage menu.

**[Download now!](http://downloads.wordpress.org/plugin/all-in-one-seo-pack.zip)**

[Support](http://blog.tcrouzet.com/plugin-wordpress-diary/) |
[Version History](http://blog.tcrouzet.com/plugin-wordpress-diary/) |
[FAQ](http://blog.tcrouzet.com/plugin-wordpress-diary/)

Some features:

* 

== Installation ==

1. Unzip into your `/wp-content/plugins/` directory. If you're uploading it make sure to upload
the top-level folder. Don't just upload all the php files and put them in `/wp-content/plugins/`.
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Visit Manage menu Diary command
1. That's it!

== Frequently Asked Questions ==

Please read these **[FAQs](http://blog.tcrouzet.com/plugin-wordpress-diary/)** before requesting
**[Support](http://blog.tcrouzet.com/plugin-wordpress-diary/)**
