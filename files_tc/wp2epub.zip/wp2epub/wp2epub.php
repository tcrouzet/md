<?php

/*
Plugin Name: wp2epub
Plugin URI: http://blog.tcrouzet.com/
Description: Generate epub files directly from WordPress, ready to publish a whole bunch of ebooks on iPad, iPhone and other readers. Just choose the tags and categories to export. It's done. You are now a bloguer and a writer. Also you wiil soon be able to export in html to open in your wordprocessor.
Author: Thierry Crouzet
Version: 0.13
Author URI: http://blog.tcrouzet.com/
*/

// CHANGE THIS IF YOU WANT TO USE A 
// DIFFERENT BACKUP LOCATION
define('WP_EPUB_DIR', 'wp-content/epub');
define('WP_EPUB_TABLE', $wpdb->prefix.'wp2epub');
define('WP_EPUB_PLUGIN','wp2epub');

class wp2epub{
		
	function __construct(){
		$this->savedir=ABSPATH.WP_EPUB_DIR."/";
		$this->debug=false;
		
		//print_r($_POST);
		
		if(!empty($_POST['do_epub'])){
			ini_set("display_errors","1");
			ini_set("memory_limit","512M");
			$this->perform_export();
		}elseif(!empty($_POST['do_base'])){
			global $wpdb;
			$keys=array_keys($_POST);
			$mores=array();
			foreach($keys as $key){
				if(eregi("do_name",$key)){
					$index=str_replace("do_name","",$key);
					if(!empty($_POST['do_name'.$index]) && !empty($_POST['do_author'.$index])){
						$mores[]=$index;
					}
				}
			}
			//print_r($mores);
			foreach($mores as $more){
				if(empty($_POST['do_order'.$more])) $order=0; else $order=1;
				if(empty($_POST['do_com'.$more])) $com=0; else $com=1;
				
				//Cover
				$img="";
				if(!empty($_FILES['do_cover'.$more]->name)){
					require_once("cozop.images.class.php");
					$img=new cozop_image();
					$imgcover=$img->preloadImage($_FILES['do_cover'.$more]);
					//print_r($imgcover);
					if(!empty($imgcover->tmp)){
						rename($imgcover->tmp,$this->savedir.$imgcover->name);
						$img=serialize($imgcover);
					}
				}
				
				$set="epub_author='".addslashes($_POST['do_author'.$more])."',epub_title='".addslashes($_POST['do_title'.$more])."',epub_tags='".addslashes($_POST['do_tags'.$more])."',epub_order='$order',epub_com='$com'";
				if(!empty($img)) $set.=",epub_cover='$img'";
				$query="INSERT LOW_PRIORITY INTO ".WP_EPUB_TABLE." SET epub_name='".addslashes($_POST['do_name'.$more])."',$set";
				$query.="ON DUPLICATE KEY UPDATE $set;";
				//echo("$query<br>");
				if($wpdb->query($query)){
					$this->export_error(__($_POST['do_title'.$more].' saved.'));
				}
				
			}
		}
		
		add_action('admin_menu', array(&$this, 'admin_menu'));
		add_filter("plugin_action_links", array(&$this, "addConfigureLink"), 10, 2);
	}

	function admin_menu() {
		add_management_page(__('wp2epub'), __('wp2epub'), 'import', basename(__FILE__), array(&$this, 'menu'));
	}
	
	function mem_option($name,$value=""){
		if(!add_option($name,$value)){
			update_option($name,$value);
		}
	}
	
	function table_exists($table){
		global $wpdb;
		$query="show tables like '$table'";
		if($wpdb->query($query)==1) return true; else return false;
	}
	
	//Adds a settings link next to Audio Player on the plugins page
	function addConfigureLink($links, $file) {
		static $this_plugin;
		if (!$this_plugin) {
			$this_plugin = plugin_basename(__FILE__);
		}
		if ($file == $this_plugin){
			$settings_link = '<a href="tools.php?page=wp2epub.php">' . __('Settings') . '</a>';
			array_unshift($links, $settings_link); // before other links
		}
		return $links;
	}
	
	function menu() {
		global $wpdb;
		$feedback='';
		$WHOOPS=FALSE;
		
		echo "<div class='wrap'>";
		echo '<h2>' . __('wp2epub') . '</h2>';
		echo 'Convert your blog to ePub by <a href="http://tcrouzet.com">Thierry Crouzet</a>.';
		
		//echo($this->savedir);
		
		if(!file_exists($this->savedir)){
			if(@mkdir($this->savedir)){
				// Give the new dirs the same perms as wp-content.
				$stat = stat( ABSPATH . 'wp-content' );
				$dir_perms = $stat['mode'] & 0000777; // Get the permission bits.
				@chmod($this->savedir,$dir_perms);
			}else{
				$this->export_error(__('WARNING: Your wp-content directory is <strong>NOT</strong> writable! We can not create the backup directory. '.$this->savedir));
			}
		}
		if(!file_exists($this->savedir.'index.php') ) {
			@touch($this->savedir."index.php");
		}
		if(!file_exists($this->savedir.'.htaccess')){
			$handle=fopen($this->savedir.".htaccess","w");
			if($handle){
				fwrite($handle,"RewriteEngine on\n");
				fwrite($handle,"RewriteRule ^(.*)\.epub$ ".ABSPATH."wp-content/plugins/wp2epub/epub.php?epub=$1&abspath=".$this->savedir."&%{QUERY_STRING} [L]\n");
				fwrite($handle,"RewriteRule ^index\.php$ ".ABSPATH."wp-content/plugins/wp2epub/list.php?abspath=".$this->savedir."&baseurl=".get_settings('siteurl')."&%{QUERY_STRING} [L]\n");
				fclose($handle);
			}else{
				$this->export_error(__('WARNING: Imposible to create .htaccess. '.$this->savedir));
			}
		}

		if(!is_writable($this->savedir)){
			$this->export_error(__('WARNING: Your backup directory is <strong>NOT</strong> writable! We can not create the backup directory '.$this->savedir));
		}
		
		//The first time create WP_EPUB_TABLE
		if(!$this->table_exists(WP_EPUB_TABLE)){
			$query="CREATE TABLE `".WP_EPUB_TABLE."` (`epub_num` int(11) NOT NULL auto_increment,`epub_name` VARCHAR( 20 ) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,`epub_author` varchar(100) character set utf8 NOT NULL,`epub_title` varchar(200) character set utf8 default NULL,`epub_tags` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,`epub_order` enum('0','1') character set ascii collate ascii_bin NOT NULL,`epub_com` enum('0','1') NOT NULL,`epub_cover` text character set ascii collate ascii_bin ,PRIMARY KEY  (`epub_num`),UNIQUE (`epub_name`)) ENGINE = MYISAM;";
			//echo($query);
			$newtable= $wpdb->query($query);
		}		
		
		// did we just do a backup?  If so, let's report the status
		if(count($this->okfile)){
			$feedback = '<div class="updated"><p>' . __('ePub generation successful') . '!</p>';
			$feedback .= '<p>' . __('Your ePub backup file has been saved on the server at '.date('H:i \t\h\e Y-m-d').'. If you would like to download it now, right click and select "Save As"</p>');
			foreach($this->okfile as $file){
				$feedback .= '<p><a href="'.get_settings('siteurl')."/$file\">$file</a> : " . sprintf(__('%s bytes'), filesize(ABSPATH.$file))."</p>";
			}
			$feedback .= '</div>';
		}
		
		//Errors
		if (count($this->export_errors)) {
			$feedback .= '<div class="updated error">' . __('The following errors were reported:') . "<pre>";
			foreach($this->export_errors as $error) {
				$feedback .= "{$error}\n";  //Errors are already localized
			}
			$feedback .= "</pre></div>";
		}
		if (!empty($feedback)) echo $feedback;

		// Give the new dirs the same perms as wp-content.
		$stat = stat( ABSPATH . 'wp-content' );
		$dir_perms = $stat['mode'] & 0000777; // Get the permission bits.

		
		if(!$WHOOPS){
			echo '<form method="post" enctype="multipart/form-data">';
			
			$query="SELECT * FROM ".WP_EPUB_TABLE." ORDER BY epub_name DESC";
			$efiles=$wpdb->get_results($query);
			if($efiles){
				$c=count($efiles);
				if($c==1) $c="1 epub"; else $c="$c epubs";
				echo '<p class="submit"><input type="submit" name="do_epub" value="Generate '.$c.'!" /> <a href="'.get_settings('siteurl')."/".WP_EPUB_DIR.'"/index.php" target="_blank">ePub index</a></p>';
			}else{
				echo '<p>In the form, fill in the fields and save.</p>';
			}
			echo '<hr><table>';
			echo '<tr><td>File</td><td>Author</td><td>Title</td><td>Tags</td><td style="text-align:center">Reverse order</td><td style="text-align:center">Comments</td><td>Cover PNG 1024*768</td></tr>';
			if($efiles){
				foreach($efiles as $efile){
					echo '<tr>';
					echo '<td><input type="text" name="do_name_'.$efile->epub_num.'" value="'.$efile->epub_name.'"></td>';
					echo '<td><input type="text" name="do_author_'.$efile->epub_num.'" value="'.$efile->epub_author.'"></td>';
					echo '<td><input type="text" name="do_title_'.$efile->epub_num.'" value="'.$efile->epub_title.'"></td>';
					echo '<td><input type="text" name="do_tags_'.$efile->epub_num.'" value="'.$efile->epub_tags.'"></td>';
					echo '<td style="text-align:center"><input type="checkbox" name="do_order_'.$efile->epub_num.'" value="1" ';
					if($efile->epub_order==1) echo('checked');
					echo'/></td>';
					echo '<td style="text-align:center"><input type="checkbox" name="do_com_'.$efile->epub_num.'" value="1" ';
					if($efile->epub_com==1) echo('checked');
					echo'/></td>';
					$imgcover=unserialize($efile->epub_cover);
					echo '<td><input type="file" name="do_cover_'.$efile->epub_num.'" value=""> '.$imgcover->name.'</td>';
					echo '</tr>';
				}
			}
			echo '<tr>';
			echo '<td><input type="text" name="do_name" value=""></td>';
			echo '<td><input type="text" name="do_author" value=""></td>';
			echo '<td><input type="text" name="do_title" value=""></td>';
			echo '<td><input type="text" name="do_tags" value=""></td>';
			echo '<td style="text-align:center"><input type="checkbox" name="do_order" value="1"/></td>';
			echo '<td style="text-align:center"><input type="checkbox" name="do_com" value="1"/></td>';
			echo '<td><input type="file" name="do_cover" value=""></td>';
			echo '</tr>';
						
			echo '</table>';
			//echo '<p class="submit"><input type="submit" name="submit" onclick="document.getElementById(\'do_base\').value=\'do_base\';" value="' . __('Save') . '!" / ></p>';
			echo '<p class="submit"><input type="submit" name="do_base" value="Save!" / ></p>';
			
			echo '</form>';
			
			echo '<h3>Notes</h3><ol>';
			echo '<li>File name must be unique, no space.</li>';
			echo '<li>Author must be filled.</li>';
			echo '<li>Title is the name of the book. Exemple: The Da Vinci Code :-)</li>';
			echo '<li>List tags or categories separeted by comas. Insert a - before a tag or a category to exclude it. Exemple: "politics,-USA" will include all the posts with the tag politics but not those with USA even if they have the tag politics.</li>';
			echo '<li>By default posts will be published chronologically starting with the oldest. Check to reverse the order: the book will start with the most recent post.</li>';
			echo '<li>Check to publish the comments.</li>';
			echo '<li>You can upload a picture for your cover. Better on iPad!</li>';
			echo '<li>On Windows, Mac OS or Linux, download ePubs and open them on <a href="http://www.lexcycle.com/">Stanza</a> or, better, <a href="http://calibre-ebook.com/">Calibre</a> (ergonomic) or <a href="http://lucidor.org/">Lucidor</a> (strict). Or on a reader like the Sony-PRS, iPad, iPhone.</li>';
			echo '<li>Validate your ePub from <a href="http://threepress.org/document/epub-validate/">epubChecker</a>.</li>';
			echo '</ol>';
		}
		
		echo '</div>';
		
	}// end wp_rtf_menu()

	function export_error($err) {
		if(count($this->export_errors) < 20) {
			$this->export_errors[] = $err;
		} elseif(count($this->export_errors) == 20) {
			$this->export_errors[] = __('Subsequent errors have been omitted from this log.');
		}
	}
	
	/***********************
	 * real code 
	 ***********************/

	function perform_export(){
		global $wpdb;
		$this->okfile=array();
		$query="SELECT * FROM ".WP_EPUB_TABLE;
		$efiles=$wpdb->get_results($query);
		if($efiles){
			foreach($efiles as $efile){
				$this->okfile[]=$this->make_file($efile);
			}
		}else{
			$this->export_error(__('No epub file denifined!'));
		}
	}
	
	function make_file($efile){
		global $wpdb;
		
		require_once("simplehtmldom/simple_html_dom.php");
		
		$this->imgindex=1;
		$this->imgtab=array();
			
		$this->contener=array();
		$this->cindex=1;
		$this->contener[$this->cindex]="";
		
		$this->ncom=0;		//Comments overall number
	
		//Cover
		if(empty($efile->epub_cover)){
			$this->contener[$this->cindex].='<h1 class="firsth1">'.$efile->epub_title."</h1>\n";
			$this->contener[$this->cindex].='<h2 class="firsth2">***</h2>';
			$this->contener[$this->cindex].='<h3 class="firsth3">'.$efile->epub_author."</h3>\n";
			$this->new_page();
		}
		
		//Page de garde
		$this->contener[$this->cindex].='<h1 class="firsth1">'.$efile->epub_title."</h1>\n";
		$this->contener[$this->cindex].='<h2 class="firsth2">'.$this->outHTTP(get_settings('siteurl'))."</h2>\n";
		$this->contener[$this->cindex].='<h3 class="firsth3">'.$efile->epub_author."</h3>\n";
		//if(!empty($morebooksurl)) $contener[$cindex].='<p><a href="'.$morebooksurl.'">Autres textes de '.stripslashes($author)." &gt;&gt;&gt;</a></p>\n";
		//if(!empty($isbn)) $contener[$cindex].='<p>ISBN : '.stripslashes($isbn)."</p>\n";
		//if(!empty($editor)) $editorplus=' et <a href="'.$editorlink.'">'.stripslashes($editor).'</a>'; else $editorplus=''; 
		$editorplus.=' - '.date("Y");
		$this->contener[$this->cindex].='<p class="firstp">&copy; <a href="'.get_settings('siteurl').'">'.$efile->epub_author.'</a>';
		$this->contener[$this->cindex].=$editorplus."</p>\n";
		$this->new_page();
		
		$query=$this->make_query($efile);
		$posts=$wpdb->get_results($query);
		$this->export_complete = false;
		if(!$posts){
			$this->export_error(__('No post find! '.$query));
			return;
		}
		
		foreach($posts as $post){
			$this->contener[$this->cindex].='<h1 class="main">'.$post->post_title."</h1>\n";
			$tmpstp=strtotime($post->post_date);
			$this->contener[$this->cindex].='<div class="soustitre">'.$this->traducdate(date("l j F y",$tmpstp))."</div>\n";
			$this->contener[$this->cindex].=$this->format_text($post->post_content);
			
			//Comments
			if($efile->epub_com==1){
				$wherecom="comment_post_ID='$post->ID'";
				$query="SELECT * FROM $wpdb->comments WHERE $wherecom ORDER BY comment_date ASC";
				//echo($query."<br>");
				//$ncomments = $wpdb->get_results("SELECT count(*) AS ncom FROM $wpdb->comments WHERE $wherecom");
				//$this->ncom+=$ncomments[0]->ncom;
				$comments=$wpdb->get_results($query);
				if($comments){
					$this->comnumber=0;
					$msg="";
					foreach($comments as $key => $c){
						if(eregi("This comment was originally posted",$c->comment_content)) continue;
						if(eregi("Topsy.com",$c->comment_author)) continue;						
						$this->comnumber++;
						$msg.="\n<h4>".strip_tags($c->comment_author)."</h4>\n".$this->format_text(strip_tags($c->comment_content));
						if($key>3) break;
					}
					$this->contener[$this->cindex].="\n<hr /><h4>".$this->comnumber." commentaires</h4>\n".$msg;
				}
			}
			
			$this->new_page();
		}
		
		//Last page	
		$this->contener[$this->cindex].='<div class="last"><p><br /><br /><br /></p>';
		$this->contener[$this->cindex].='<p><br /><br /><br />printed the '.date("j/n/Y").'</p>';
		$this->contener[$this->cindex].="</div>\n";
		
		if($this->debug) exit;
		
		$this->epub_title=$efile->epub_title;
		$this->epub_author=$efile->epub_author;
		$this->epub_isbn="";
		return($this->make_epub($efile));
	}

	function make_query($efile){
		global $wpdb;

		$ids=array();
		$exclude=array();
		$names=array();
		$tags=trim($efile->epub_tags);
		//echo($efile->epub_tags."<br>");
		$tags=trim($tags,",");
		$tags=trim($tags);
		$tags=explode(",",$tags);
		if(count($tags)){
			$q="";
			foreach($tags as $tag){
				$originaltag=trim($tag);
				$tag=trim($tag,"-");
				if($originaltag!=$tag) $exclude[]=$tag;
				if(empty($tag)) continue;
				if(!empty($q)) $q.=" OR ";
				$q.="name='".addslashes(trim($tag))."'";
			}
			//echo($q."<br>");
			if(!empty($q)){
				$query="SELECT term_taxonomy_id,name FROM ".$wpdb->terms.",".$wpdb->term_taxonomy." WHERE ".$wpdb->terms.".term_id=".$wpdb->term_taxonomy.".term_id AND ($q)";
				//echo($query."<br>");
				$term_taxonomy_id=$wpdb->get_results($query);
				foreach($term_taxonomy_id as $id){
					$ids[]=$id->term_taxonomy_id;
					$names[$id->term_taxonomy_id]=$id->name;
				}
				//print_r($ids);
				//print_r($names);
			}
		}
		//print_r($exclude);
		
		$query="SELECT *,COUNT(DISTINCT term_taxonomy_id) as termsnbr FROM ";

		$total=count($ids);
		if($total>0){
			$query.=$wpdb->term_relationships.",";
		}
		$query.="$wpdb->posts WHERE post_status='publish'";
		//$query.=" AND ID='8912'";			//test on a single post
		
		$termouts=array();
		$neototal=$total;
		if($total>0){
			$query.=" AND object_id=ID AND (";
			$first=true;
			foreach($ids as $id){
				if(!$first) $query.=" OR ";
				if(in_array($names[$id],$exclude,true)) {$neototal--;$termouts[]=$id;}
				$query.="term_taxonomy_id='".$id."'";
				$first=false;
			}
			$query.=") ";
		}
		
		if($total>0){
			$query.=" GROUP BY ID HAVING termsnbr=$neototal";
			foreach($termouts as $term){
				$query.=" AND term_taxonomy_id<>$term";
			}
		}
		
		$query.=" ORDER BY post_date_gmt ";
		if($efile->epub_order==1) $query.="DESC"; else $query.="ASC";   
		//$query.=" LIMIT 6";
		//echo($query."<br>");
		return $query;		
	}
	
	function make_epub($efile){
		require_once("zipcreate/zipcreate.class.php");
		$tstamp = time();		// timestamp for zip entries
		$epub= new ZipCreate();
		
		$imgcover="";
	
		$prev_encoding = $epub->ztype;
		$epub->ztype = 'store';
		$epub->add_file('application/epub+zip', 'mimetype', $tstamp);
		$epub->ztype = $prev_encoding;
	
		//META-INF
		$epub->add_file($this->make_container(),'META-INF/container.xml',$tstamp);

		//Image
		if(!empty($efile->epub_cover)){
			$imgcover=unserialize($efile->epub_cover);
			$epub->add_file(file_get_contents($this->savedir.$imgcover->name),'OEBPS/images/imgcover.'.$imgcover->type, $tstamp);
			$epub->add_file($this->cover_make($imgcover),'OEBPS/text/cover.xhtml',$tstamp);
		}else{
			$imgcover="";
		}
		
		//OEBPS
		$epub->add_file($this->opf_maker($imgcover), 'OEBPS/content.opf', $tstamp);
		$epub->add_file($this->ncx_maker(), 'OEBPS/toc.ncx', $tstamp);
		foreach($this->contener as $key => $ops){
			$epub->add_file($this->ops_maker($ops,$this->epub_title),'OEBPS/text/book'.str_pad($key,4,"0",STR_PAD_LEFT).'.xhtml',$tstamp);
		}
		
		//CSS
		$epub->add_file($this->ops_style(),'OEBPS/styles/main.css', $tstamp);
		
		
		foreach($this->imgtab as $key => $value){
			$epub->add_file(file_get_contents($value),'OEBPS/images/'.$key.'.'.$this->imgxtension($value), $tstamp);
		}		
		
		// finish it up and download
		$output_file = $epub->build_zip();
		$output_name=$efile->epub_name.".epub";
		$this->export_file=WP_EPUB_DIR."/".$output_name;
		if(!$this->saveFile(ABSPATH.$this->export_file,$output_file)){
			$this->export_error(__('Could not save '.$this->export_file));
			return;
		}else{
			$this->export_complete=true;
			return $this->export_file; 
		}
	}

	function make_container(){
		$msg='<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml" />
  </rootfiles>
</container>';
		return $msg;	
	}

	function opf_maker($imgcover){		
		$opf='<?xml version="1.0"?>';
		$opf.="\n";
		$opf.='<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="BookID" version="2.0">';
		$opf.="\n";
	
		$opf.='<metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">';
		$opf.="\n";
		$opf.="<dc:title>".stripslashes($this->epub_title)."</dc:title>\n";
	    $opf.="<dc:language>fr</dc:language>\n";
	    $opf.='<dc:identifier id="BookID" opf:scheme="ISBN">'.$this->epub_isbn."</dc:identifier>\n";
	    $opf.='<dc:creator opf:role="aut">'.stripslashes($this->epub_author)."</dc:creator>\n";
	    $opf.='<dc:publisher>'.stripslashes($this->epub_author)."</dc:publisher>\n";
	    //$opf.='<dc:genre>'.stripslashes("blog")."</dc:genre>\n";
	    if(!empty($imgcover->tmp)){
	    	$opf.='<meta name="cover" content="cover-image"/>';    	
			$opf.="\n";
		}
		$opf.="</metadata>\n";
	 
		$opf.="<manifest>\n";
	    $opf.='<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>';
		$opf.="\n";
	    $opf.='<item id="stylesheet" href="styles/main.css" media-type="text/css"/>';
		$opf.="\n";
		
		//Images
		if(!empty($imgcover->tmp)){
	    	$opf.='<item id="cover-image" href="images/imgcover.'.$imgcover->type.'" media-type="image/png"/>';
			$opf.="\n";
	    	$opf.='<item id="cover" href="text/cover.xhtml" media-type="application/xhtml+xml"/>';
	    	$opf.="\n";
		}
		foreach($this->imgtab as $key => $value){
	    	$opf.='<item id="image.'.$key.'" href="images/'.$key.'.'.$this->imgxtension($value).'" media-type="image/png"/>';
			$opf.="\n";
		}		
		
		foreach($this->contener as $key => $ops){
			$opf.='<item id="book'.str_pad($key,4,"0",STR_PAD_LEFT).'" href="text/book'.str_pad($key,4,"0",STR_PAD_LEFT).'.xhtml" media-type="application/xhtml+xml"/>'."\n";
		}
		$opf.="</manifest>\n";
	 
		$opf.="<spine toc=\"ncx\">\n";
		if(!empty($imgcover->tmp)){
	    	$opf.="<itemref idref=\"cover\"/>\n";
		}
		foreach($this->contener as $key => $ops){
			$opf.='<itemref idref="book'.str_pad($key,4,"0",STR_PAD_LEFT).'"/>'."\n";
		}
		$opf.="</spine>\n";
		
		$opf.="<guide>\n";
		if(!empty($imgcover->tmp)){
			$opf.="<reference  href=\"text/cover.xhtml\" type=\"cover\" title=\"Cover\"/>\n";
		}
	  	$opf.="</guide>";
		
	 
		$opf.='</package>';
		return $opf;
	}

	function ncx_maker(){
		$msg='<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE ncx PUBLIC "-//NISO//DTD ncx 2005-1//EN" "http://www.daisy.org/z3986/2005/ncx-2005-1.dtd">
<ncx version="2005-1" xml:lang="en" xmlns="http://www.daisy.org/z3986/2005/ncx/">
<head>
    <meta name="dtb:uid" content="'.$this->epub_isbn.'"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
</head>
 
<docTitle>
    <text>'.stripslashes($this->epub_title).'</text>
</docTitle>
 
<docAuthor>
    <text>'.stripslashes($this->epub_author).'</text>
</docAuthor>
 
<navMap>';

		$max=count($this->contener);
		$ordi=1;
		foreach($this->contener as $key => $ops){
			
			if($key==1)
				$h3="Couverture";
			elseif($key==$max)
				continue;
			else{
				preg_match_all('!<h1 class="main">(.*?)</h1>!i',$ops,$matches);
				$h3=str_replace("&nbsp;","",$matches[1][0]);
				$h3=mb_convert_case($h3, MB_CASE_TITLE, "UTF-8");
				if(empty($h3)){
					preg_match_all('!<h3 class="main">(.*?)</h3>!i',$ops,$matches);
					$h3=str_replace("&nbsp;","",$matches[1][0]);
					$h3=mb_convert_case($h3, MB_CASE_TITLE, "UTF-8");
				}			
			}
			
			$id='book'.str_pad($key,4,"0",STR_PAD_LEFT);
			$msg.='<navPoint class="chapter" id="'.$id.'" playOrder="'.$ordi.'">'."\n";
			$msg.='<navLabel><text>'.$h3.'</text></navLabel>'."\n";
			$msg.='<content src="text/'.$id.'.xhtml"/>'."\n";
			$msg.="</navPoint>\n"; 
			$ordi++;
		}
	
		$msg.='</navMap></ncx>';
		return $msg;
	}

	function ops_maker($main,$title){
		$msg='<?xml version="1.0" encoding="UTF-8" ?>';
		$msg.="\n";
		$msg.='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'; 
		$msg.="\n";
		$msg.='<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">';	
		$msg.="\n";
		$msg.="<head>\n";
	    $msg.='<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />';
		$msg.="\n";
	    $msg.='<title>'.stripslashes($title)."</title>\n";
	    $msg.='<link rel="stylesheet" href="../styles/main.css" type="text/css" />';
		$msg.="\n";
	    $msg.="</head>\n";
	    $msg.="<body>\n";
	    $msg.=$main;
		$msg.="\n</body>\n</html>";
		//exit($msg);
		return $msg;	
	}

	function ops_style(){
	
		$msg='div.cover{text-align:center;background-color:#fff}'."\n";
		$msg.='div.cover img{width:100%;margin:0;padding:0}'."\n";
		$msg.='#cover-image{width:100%;margin:0;padding:0}'."\n";
	
		$msg.='h1.firsth1{color:#000000;font-size:2em;font-family:sans-serif;}'."\n";
		$msg.='h2.firsth2{color:#CCCCCC;font-size:2em;font-family:sans-serif}'."\n";
		$msg.='h3.firsth3{color:#a40800;font-size:2em;font-family:sans-serif}'."\n";
		$msg.='p.firstp{font-family:sans-serif;font-size:0.8em}'."\n";
		
		$msg.='div.last{text-align:center;background-color:#fff}'."\n";
	
		$msg.='p{text-align:justify}'."\n";
		$msg.='img{border:0;width:100%}'."\n";
		
		$msg.='h3.main{font-family:Arial,Helvetica,san-serif;line-height:1em;font-size:1.5em;font-weight:bold;margin-bottom:0em;margin-top:0.em;margin-right:0em;margin-left:0em;text-indent:0em;text-align:center;font-style:normal;color:rgb(0,0,0);
		border-width:1px 0px 1px 0px;
		border-style:solid;
		padding-left:0em;padding-right:0em;padding-top:.20em;}'."\n";
	
		$msg.='h1.main{font-family:Arial,Helvetica,san-serif;line-height:1em;font-size:1.5em;font-weight:bold;margin-bottom:.5em;margin-top:1em;margin-right:0em;margin-left:0em;text-indent:0em;text-align:center;font-style:normal;color:#a40800;
		border-width:2px 0px 2px 0px;border-style:solid;border-color:#a40800;
		padding-left:0em;padding-right:0em;padding-top:.20em;}'."\n";
		
		$msg.='h4.main{font-family:Arial,Helvetica,san-serif;line-height:1em;margin-top:2em;margin-bottom:1em}'."\n";
		
		$msg.='.pi{font-family:serif;line-height:1.30em;text-indent:0em;
		margin-bottom:0em;margin-top:1em;margin-right:0em;margin-left:0em;
		text-align:justify;font-weight:normal;font-style:normal}'."\n";
	
		$msg.='.lexique{font-family:serif;line-height:1.30em;text-indent:0em;
		margin-bottom:0em;margin-top:1em;margin-right:0em;margin-left:0em;
		text-align:justify;font-weight:normal;font-style:italic}'."\n";
		
		$msg.='.exergue{font-family:serif;text-indent:0em;margin-right:1em;margin-left:1em;margin-top:5em;
		text-align:justify;font-weight:normal;font-style:italic;color:rgb(0,0,0);}'."\n";
		$msg.='.exerguetitre{font-family:serif;text-indent:0em;margin-right:1em;margin-left:1em;margin-top:0em;;margin-bottom:1em;
		text-align:right;font-weight:normal;color:rgb(0,0,0);}'."\n";
		
		$msg.='.blockquote{margin-top:1em;margin-bottom:1em;padding-left:1em;padding-right:1em;font-style:italic;text-indent:0em;}'."\n";
		$msg.='.surtitre{text-align:center;margin-bottom:1em;font-variant:small-caps}'."\n";
		$msg.='.soustitre{text-align:center;margin-bottom:2em}'."\n";
		$msg.='.smallcaps{font-variant:small-caps}'."\n";

		return $msg;
	}

	function cover_make($imgcover){
		$msg='<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US"><head>
    <title>Cover</title>
    <link rel="stylesheet" type="text/css" href="../styles/main.css" />
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
</head>
<body>
  	<div></div>
	<p><img id="cover-image" src="../images/imgcover.'.$imgcover->type.'" alt="bookcover" /></p>
</body>
</html>';
		return $msg;
	}
	
	function new_page(){
		$this->contener[$this->cindex]=trim($this->contener[$this->cindex]);
		$this->contener[$this->cindex]=trim($this->contener[$this->cindex],"\n");
		if(empty($this->contener[$this->cindex])) return;
		$this->cindex++;
		$this->contener[$this->cindex]="";
	}

	function format_text($msg){

		//Delete PHP code
		$msg=preg_replace("/<\?php(.*)\?>/si","",$msg);
		
		//Mark lines
		$msg=mb_eregi_replace(0x0D,"</p><p>",$msg);
		$msg=mb_eregi_replace(0x0A,"",$msg);
		$msg=str_replace("--","�",$msg);
		$msg=str_replace("	","",$msg);
		$msg="<p>".$msg."</p>";
		$msg=str_replace("<p><p>","<p>",$msg);
		$msg=str_replace("</p></p>","</p>",$msg);
		$msg=str_replace("<p></p>","",$msg);
		$msg=str_replace("</p><p></em></p>","</em></p>",$msg);

		$msg=str_replace("<p><h3>","<h3>",$msg);
		$msg=str_replace("</h3></p>","</h3>\n",$msg);
			
		$msg=str_replace("<p><ol></p>","<ol>\n",$msg);
		$msg=str_replace("<p></ol></p>","</ol>\n",$msg);
		$msg=str_replace("<p><ul></p>","<ul>\n",$msg);
		$msg=str_replace("<p></ul></p>","</ul>\n",$msg);
		$msg=str_replace("</p><p><li>","</li>\n<li>",$msg);
		$msg=str_replace("</li></li>","</li>",$msg);
		
		$msg=str_replace("<blockquote></em>","<blockquote>",$msg);
		
		if(false&&class_exists(tidy)){
			echo("tidy");
			$tidy = new tidy();
			$msg= @$tidy->repairString($msg,false,"utf8");
		}else{
			$msg="<body>".$msg."</body>";
		}
		
		//echo($msg);
		
		//return $msg;
		$this->fout="";
		$this->pile=array();
		$parser=new simple_html_dom();
		$parser->load($msg);
		foreach($parser->find('body') as $body) {break;}
		//print_r($body);exit;
		$this->html_tree($body);
		$this->fout=str_replace("</p>","",$this->fout);
		//return $msg;
		if($this->debug) echo(htmlentities($this->fout));
		return $this->fout;
	}

	function html_tree($node){
		$indebug=$this->debug;
		
		if($node->tag=="unknown") return;
		if($node->tag=="object") return;
		
		$child=true;
		$closediv=false;
		
		if($indebug) echo("$node->tag<br>");
		
		$tag=$node->tag;
		if($node->tag=="text"||empty($node->tag)){
			$this->fout.=$node->innertext;
			if($indebug) echo($node->innertext."<br />");
			$child=false;
		}elseif($node->tag=="body"||$node->tag=="div"){
		}elseif($node->tag=="span"){
		}elseif($node->tag=="a"){
			$this->fout.="<".$node->tag;
			foreach($node->attr as $key=>$value){
				if($key=="name"||$key=="href") $this->fout.=" $key=\"$value\"";
			}
			$this->fout.=">";
		}elseif($node->tag=="br"){
			$this->fout.='<br/>';
		}elseif($node->tag=="p"){
			$this->fout.='<div class="pi">';
			//array_push($this->pile,"</div>");
			$closediv=true;
		}elseif($node->tag=="blockquote"){
			$this->fout.='<div class="blockquote">';
			//array_push($this->pile,"</div>");
			$closediv=true;
		}elseif($node->tag=="h1"){
			$this->fout.='<h1 class="main">';
		}elseif($node->tag=="h2"){
			$this->fout.='<h2 class="main">';
		}elseif($node->tag=="h3"){
			$this->fout.='<h3 class="main">';
		}elseif($node->tag=="h4"){
			$this->fout.='<h4 class="main">';
		}elseif($node->tag=="img"){
			foreach($node->attr as $key=>$value){
				if($key=="src") $url=$value;
			}
			if(!empty($url)){
				$this->imgtab[$this->imgindex]=$url;
				$this->fout.='<img src="../images/'.$this->imgindex.'.'.$this->imgxtension($url).'">';
				$this->imgindex++;
			}
		}else{
			$this->fout.="<".$node->tag.">";
		}
			
		//Explore the children
		if(count($node->nodes)>0 && $child){
			foreach($node->nodes as $child){
				$this->html_tree($child);
			}
		}
		    
		if($closediv){
			$this->fout.="</div>\n";
		}elseif($span){
			$this->fout.="</span>";
		}elseif($node->tag=="p"){			
		}elseif($node->tag!="text"&&!empty($node->tag)&&$node->tag!="span"&&$node->tag!="body"&&$node->tag!="br"&&$node->tag!="div"&&!eregi(":",$node->tag)){
			$this->fout.="</".$node->tag.">";
		}
	}

	function imgxtension($url){
		$info=parse_url($url);
		$info=pathinfo($info['path']);
		return $info['extension'];
	}

	function traducDate($content) {
		$dateUS=array('January','February','March','April','May','June','July','August','September','October','November','December','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
		$dateFR=array('janvier','f�vrier','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','d�cembre','lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche');
		return str_replace($dateUS,$dateFR,$content);
	}
	
	function saveFile($name,$msg){
		$this->delfile($name);
		$fp=@fopen($name,'w');
		if(!empty($fp)) {
			@fputs($fp,$msg);
			@fclose($fp);
			return true;
		}else
			return false;
	}
	
	function delfile($img) {
		if(@file_exists($img)){
			if(@unlink($img)) return true;
			$this->error="Impossible to unlink $img (1)";
			if(!@chmod($img,0777)){
				$this->error="Impossible to cmod $img";
				return false;
			}
			if(@unlink($img)) return true;
			$this->error="Impossible to unlink $img (2)";
			return false;
		}else{
			$this->error="File $img do not exist";
			return false;
		}
	}

	//Supprime http:// d'un url
	function outHTTP($ad) {
		return ereg_replace('http://','',$ad);
	}
	
}

function wp2epub_init() {
	global $epub;
	$epub=new wp2epub(); 	
}

add_action('plugins_loaded','wp2epub_init');

?>