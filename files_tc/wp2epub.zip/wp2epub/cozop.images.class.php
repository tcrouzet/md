<?php
//require_once 'filesmanag_inc.php';

class cozop_image{
	
	
	public $error="";
	public $mode="";			//Type de recadrage
	public static $bank="";
	public static $depot="";
	public static $userbank="";
	public static $letterbank="";
	public static $jpegqual=80;		//Compress
	public $ext=0;				//1:GIF 2:JPEG 3:PNG
	public $portrait=true;		//Recadrer plutot vers le haut
	public $cache=true;		//Cache on
	public static $memcahe=256;
	public static $bad_images =array();
	
	function __construct() 
	{
		cozop_image::_construct();
	}
	public static function _construct()//constructeur statique (voir autoload)
    {
		//ini_set("memory_limit",cozop_image::$memcahe."M");
		cozop_image::$bank=COZOP_DATA_IMG_PATH."imgbank/";
		cozop_image::$depot=COZOP_DATA_IMG_PATH."imgdepot/";
		cozop_image::$userbank=COZOP_DATA_IMG_PATH."userbank/";
		cozop_image::$letterbank=COZOP_DATA_IMG_PATH."letterbank/";
    }
	function newimage($sourcefile,$w,$h,$char){
		$target=$this->bankdir($sourcefile,$w,$h);
		$file=$target->dir.$target->name;

		//Image in cache
		if($this->cache&&$this->showJPG($file)){
			return true;
		}
//	ct::dbg($file." ".$w." ".$h." ".$sourcefile);
		if(!@file_exists($target->dir)){
			if(!FileManager::mkDossier($target->dir)){
				$this->error="Impossible to create dir : $target->dir";
				return false;		
			}
		}
		$this->mode="";
		if($this->resizeImage($sourcefile,$file,$w,$h)){
			//Image resiz�
			return $this->showJPG($file);
		}else{
			//Impossible de retrouver l'image
			ct::dbg("!!!image bug: $file $w $h $sourcefile");
			for($i=0;$i<10;$i++){
				$itmp=str_replace(".jpg","$i.jpg",$file);
				if(@file_exists($itmp)) break;
			}
			if($i==10){
				//Premier bug
				return $this->letter($char,$w,$h,$itmp);				
			}elseif($i==0){
				//Dead image
				if(@rename($itmp,$file)) return $this->showJPG($file);
			}else{
				//Bug $i
				$k=$i-1;
				$inew=str_replace("$i.jpg","$k.jpg",$itmp);
				if(@rename($itmp,$inew)) return $this->showJPG($inew);
			}
		}
		return false;
	}

	/** Make file from img url */
	function bankdir($sourcefile,$w,$h){
		$sha=md5($sourcefile);
		$sha_tmp=$sha."000";
		$path->dir=cozop_image::$bank.$sha_tmp[0]."/".$sha_tmp[1]."/".$sha_tmp[2]."/";
		$path->name=$sha."_".$w."_".$h.".jpg";
		return $path;
	}

	/** Path to a depot image */
	function depotdir($id){
		//echo "depot : ".cozop_image::$depot;
		$idrev=strrev(strval(abs($id)))."000";
		$path->dir=cozop_image::$depot.$idrev[0]."/".$idrev[1]."/".$idrev[2]."/".$id."/";		
		$path->baseurl=Constants::httpMedia."imgdepot/".$idrev[0]."/".$idrev[1]."/".$idrev[2]."/".$id."/";
		return $path;
	}
	
	/** Make dir from name url */
	function userdir($name){
		$path=$this->userpath($name);
		//Create dir
		if(!@file_exists($path)){
			if(!FileManager::mkDossier($path)){
				$this->error="Impossible to create dir : $path";
				ct::dbg("userdir : ".$this->error);
				return false;		
			}
		}
		//ct::dbg("userpath = $path");
		return $path;
	}

	/** Make path from name url */
	function userpath($name){
		$sha_tmp=strrev($name)."000";
		$path=cozop_image::$userbank.$sha_tmp[0]."/".$sha_tmp[1]."/".$sha_tmp[2]."/";
		
		return $path;
	}
	
	/** Retourne taille */
	function get_size($sourcefile){
		//ct::backtrace();
		//ct::dbg("getsize $sourcefile");
		$tmp=getimagesize($sourcefile,$info);
		$picsize->x=$tmp[0];
		$picsize->y=$tmp[1];
		$picsize->type=$tmp[2];		//Extension
		$picsize->html=$tmp[3];
		$picsize->mime=$tmp['mime'];		
		if(isset($tmp['bits'])) $picsize->bits=$tmp['bits']; else $picsize->bits=8;
		if($picsize->bits<8) $picsize->bits=8;  
		return $picsize;
	}

	/** http://www.magickwand.org/ */
	function correct($sourcefile){
		return false; // TODO : trouver un moyen de corriger les images sans magickwand
		
		$targetfile="/tmp/img".rand(0,1000000);@unlink($targetfile);
		$img=@file_get_contents($sourcefile);
		if(!file_put_contents($targetfile,$img)){
			$this->error="Impossible to correct";			
			return false;
		}
		$magick_wand=NewMagickWand();
		MagickReadImage($magick_wand,$targetfile);
		if(!MagickSetFormat($magick_wand,"JPEG")){
			ct::dbg("magicwand merde");
		}
		if(!MagickWriteImage($magick_wand,$targetfile)){
			$this->error="Impossible to save";			
			return false;
		}
		$pic=$this->get_size($targetfile);
		if($pic->type!=IMAGETYPE_JPEG) return false;
		$pic->sourcefile=$targetfile;
		ct::dbg("correct : ".$targetfile);
		return $pic;
	}
	
	/** Resize et recadre */
	function resizeImage($sourcefile,$targetfile,$w=0,$h=0)
	{
		ct::backtrace();
		//ct::dbg("resize : $sourcefile -> $targetfile $w $h");
		//ct::dbg("Mem limit :".ini_get("memory_limit"));
		
		// Get the dimensions of the source picture
		$picsize=$this->get_size($sourcefile);
		if(!$picsize) 
		{
			$this->error.="get_size failed for $sourcefile";	
			ct::dbg($this->error);		
			return false;
		}

		//ct::dbg("pictype = ".$picsize->type);
		//Find image type
//		$this->ext=$picsize->type;
		if($picsize->type!=IMAGETYPE_GIF&&$picsize->type!=IMAGETYPE_PNG&&$picsize->type!=IMAGETYPE_JPEG){
			$picsize=$this->correct($sourcefile);
			if(!$picsize){
				$this->error.="img type unknown : $picsize->type";			
				ct::dbg($this->error);
				return false;
			}else{
				$sourcefile=$picsize->sourcefile;
			}
		}

		//ct::dbg("imagetype ok");
//		if($_SERVER['REMOTE_ADDR']=='82.238.237.6') ct::dump("source:$sourcefile x:$picsize->x y:$picsize->y w:$w h:$h");exit;
		
		//Delete if exists
		supFile($targetfile);
		
		//ct::dbg("image size : $picsize->x x $picsize->y x $picsize->bits");
		//Just move
		$imagesize=intval(($picsize->x*$picsize->y*$picsize->bits*2.4)/(1024*1024));
		//ct::dbg("image mem size : ".$imagesize);
		if($w==0 && $h==0 
			&& $picsize->type==IMAGETYPE_JPEG)
		{
			//ct::dbg("resizeImage $sourcefile : no resize & jpeg => copy source file (mode : ".$this->mode.")");
			if(TRUE === copy($sourcefile,$targetfile))
			{
				//ct::dbg("copy ok");
				return true;
			}
			else
			{
				ct::dbg("copy failed from $sourcefile to $targetfile");
			}
		}
		
		if($w==0) $w=$picsize->x;
		if($h==0) $h=$picsize->y;
		
		//ct::dbg("create image");
		
		//Create image
		//if($imagesize>$this->memcahe) ini_set("memory_limit",$imagesize."M");
		
		
		$source_id=false;
		if($picsize->type==IMAGETYPE_JPEG){
			$source_id=imagecreatefromjpeg($sourcefile);
		}elseif($picsize->type==IMAGETYPE_GIF)
			$source_id=imagecreatefromgif($sourcefile);
		elseif($picsize->type==IMAGETYPE_PNG)
			$source_id=imagecreatefrompng($sourcefile);
		if(!$source_id){
			$this->error="$picsize->type creation impossible";
			ct::dbg($this->error);
			return false;
		}
		//ct::dbg("image id $source_id");
		
		if(isset($picsize->sourcefile)){
			//Tmp utilis� pour corrections
			@unlink($picsize->sourcefile);
		}
		
		
		//flo 31/12/08 : si l'image source est petite, on ne retaille pas plus gros, sans quoi
		// �a pixelise. 
		if($mode=='')
		{
			$w=min($w,$picsize->x);
			$h=min($h,$picsize->y);
		}
		
		//Format
		if($this->mode!="iso"){
			$target_id=imagecreatetruecolor($w,$h);
		}
		
		switch($this->mode) {
		case "tojpeg":
			//Recr� l'image en jpeg sans rien changer
			imagecopyresampled($target_id,$source_id,0,0,0,0,$picsize->x,$picsize->y,$picsize->x,$picsize->y);
		break;
		case "deforme":
			//Ne respecte pas l'isom�trie
			imagecopyresampled($target_id,$source_id,0,0,0,0,$w,$h,$picsize->x,$picsize->y);
		break;
		case "iso":
			//R�duit au mieux et garde proportion
			if($picsize->x>$picsize->y){
				$h=intval(($picsize->y*$w)/$picsize->x);
			}else{
				$w=intval(($picsize->x*$h)/$picsize->y);
			}
			$target_id=imagecreatetruecolor($w,$h);
			imagecopyresampled($target_id,$source_id,0,0,0,0,$w,$h,$picsize->x,$picsize->y);
		break;
		case "isow":
			//R�duit h proportionnelement � w
			$h=intval($w*$picsize->y/$picsize->x);
			imagecopyresampled($target_id,$source_id,0,0,0,0,$w,$h,$picsize->x,$picsize->y);
		break;
		case "isowmax":
			//R�duit h proportionnelement � w si source plus grande
			if($picsize->x>$w){
				$h=intval($w*$picsize->y/$picsize->x);
				$target_id=imagecreatetruecolor($w,$h);
				imagecopyresampled($target_id,$source_id,0,0,0,0,$w,$h,$picsize->x,$picsize->y);
			}else{
				$target_id=$source_id;
			}
		break;
		case "centre":
			//Conserve les proportion et noir en fond
	//		$background=imagecolorallocate($target_id,255,255,255);
	//		imagefill($target_id,0,0,$background);
			if($picsize->x>$picsize->y){
				$x=0;
				$y=$h;
				$h=intval(($picsize->y*$w)/$picsize->x);
				$y=intval(($y-$h)/2);
			}else{
				$y=0;
				$x=$w;
				$w=intval(($picsize->x*$h)/$picsize->y);
				$x=intval(($x-$w)/2);
			}
			imagecopyresampled($target_id,$source_id,$x,$y,0,0,$w,$h,$picsize->x,$picsize->y);
		break;
		default:
			//Recadre au centre sans d�former, pas de bordure noire
			$r=$w/$h;						//Target
			$rs=$picsize->x/$picsize->y;	//Source
			$cx=0;
			$cy=0;
			if($r>=1&&$rs>=1){
				//M�me sens horizontal
				if($r>$rs){
					//�largi h
					$nw=$w;
					$nh=$w/$rs;
					$cy=intval($picsize->y*(1-$h/$nh)/2);
				}else{
					//�largi w
					$nw=$h*$rs;
					$nh=$h;
					$cx=intval($picsize->x*(1-$w/$nw)/2);
				}
			}elseif($r>=1&&$rs<1){
				//Target horizontale, sourse verticale
				//Ramener la largeur � w, couper en hauteur (corrig� 31/10/07)
				$nw=$w;
				$nh=$w/$rs;
				if($this->portrait) $div=3.5; else $div=2;
				$cy=intval($picsize->y*(1-$h/$nh)/$div);
			}elseif($r<1&&$rs>1){
				//Target verticale, sourse horizontale
				$nw=$h*$rs;
				$nh=$h;
				$cx=intval($picsize->x*(1-$w/$nw)/2);
			}else{
				//M�me sens vertical
				if($r>$rs){
					//Source plus �troite - �largir h
					$nw=$w;
					$nh=$w/$rs;
					$cy=intval($picsize->y*(1-$h/$nh)/2);
				}else{
					//Source plus large - �largir w
					$nw=$h*$rs;
					$nh=$h;
					$cx=intval($picsize->x*(1-$w/$nw)/2);
				}
			}
			if(!imagecopyresampled($target_id,$source_id,0,0,$cx,$cy,$nw,$nh,$picsize->x,$picsize->y)){
				$this->error="Resize bug";
				ct::dbg($this->error);
				imagedestroy($target_id);
				imagedestroy($source_id);
				return false;
			}
		break;}
		
		//Output
		imagejpeg($target_id,$targetfile,cozop_image::$jpegqual);
		imagedestroy($target_id);
		imagedestroy($source_id);
		
		//ct::dbg("resize ok");
			
		return true;
	}
		
	/** Affiche une image si elle existe */
	function showFile($file){
	
	   //Gather relevent info about file
	   $len = filesize($file);
	   $filename = basename($file);
	   $file_extension = strtolower(substr(strrchr($filename,"."),1));
	
	   //This will set the Content-Type to the appropriate setting for the file
		switch( $file_extension ) {
			case "pdf": $ctype="application/pdf"; break;
			case "exe": $ctype="application/octet-stream"; break;
			case "zip": $ctype="application/zip"; break;
			case "doc": $ctype="application/msword"; break;
			case "xls": $ctype="application/vnd.ms-excel"; break;
	     	case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
	     	case "gif": $ctype="image/gif"; break;
	     	case "png": $ctype="image/png"; break;
	     	case "jpeg":
	     	case "jpg": $ctype="image/jpeg"; break;
	     	case "mp3": $ctype="audio/mpeg"; break;
	     	case "wav": $ctype="audio/x-wav"; break;
	     	case "mpeg":
	     	case "mpg":
	     	case "mpe": $ctype="video/mpeg"; break;
	     	case "mov": $ctype="video/quicktime"; break;
	     	case "avi": $ctype="video/x-msvideo"; break;
	
	     	//The following are for extensions that shouldn't be downloaded (sensitive stuff, like php files)
	     	case "php":
	     	case "htm":
	     	case "html":
	     	case "txt": return false; break;
	     	default: $ctype="application/force-download";
	   }

	   //Begin writing headers
	   header("Pragma: public");
	   header("Expires: 0");
	   header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	   header("Cache-Control: public"); 
	   header("Content-Type: $ctype");
	   header("Content-Length: ".$len);
	   @readfile($file);
	   return true;	
	}

	/** Affiche une image si elle existe */
	function showJPG($file){
		//http://media.cozop.com/letter/120/202/L.jpg
		$msg=@file_get_contents($file);
		//echo($msg);
		//die;
		if(!$msg) return false;
		$len=strlen($msg);
		header("Pragma: public");
		header("Expires:  Fri, 30 Oct 2020 14:19:41 GMT");
		header("Content-Type: image/jpeg");
		header("Content-Length: ".$len);
		
		
		return true;	
	}
	
	/** Fabrique une lettrine et l'affiche */
	function imgerror($code,$w,$h){
		$im=@imagecreatetruecolor($w,$h);
		if (!$im){
			$this->error="Impossible to create letter";
			return false;
		}
		$text_color=imagecolorallocate($im,0xFF,0xFF,0xFF); 		//white
		$background_color=imagecolorallocate($im,0xA3,0xA3,0xA3);	//Gris

		$font="myriadbold.ttf";
		$size=intval($h/12);
		$x=1;
		$y=$h*0.9;
		
		$r=imagettftext($im,$size,0,$x,$y,$text_color,$font,$code);
		
		Header("Content-Type: image/Png");
		imagepng($im);
		imagedestroy($im);
	}
	
	/** Fabrique une lettrine et l'affiche */
	function letter($char,$w,$h,$file=""){

		if(empty($file)) $file=cozop_image::$letterbank.$char."_".$w."_".$h.".jpg";

		//Image in cache
		if($this->cache&&$this->showJPG($file)){
			return true;
		}
//		ct::dbg($file." ".$w." ".$h." ".$char);
		
		$im=@imagecreate($w,$h);
		if (!$im){
			$this->error="Impossible to create letter";
			return false;
		}
//		$background_color=imagecolorallocate($im,0,0,0); //black
		$background_color=imagecolorallocate($im,0xFF,0xFF,0xFF); //white
		$text_color=imagecolorallocate($im,0xA3,0xA3,0xA3);	//Gris

		$font="myriadbold.ttf";
		$size=intval($h/1.1);
		$x=intval($w/5);
		$y=$h*0.9;
		
		$r=imagettftext($im,$size,0,$x,$y,$text_color,$font,$char);
		
		//Output
		imagejpeg($im,$file,cozop_image::$jpegqual);
		return $this->showJPG($file);
	}
	
	/** analyse $_FILES['imgfile'] */
	function preloadImage($imgfile){
		if(!isset($imgfile['size'])){
			$this->error="Image vide";
			return false;
		}
		$this->error=$imgfile['error'];
		if($this->error>0) return false;

		$img->name=$imgfile['name'];
		$img->tmp=$imgfile['tmp_name'];
		$it=explode('/',$imgfile['type']);
		$img->type=str_replace(array("pjpeg","jpeg"),"jpg",$it[1]);
		$img->size=$imgfile['size'];

		return $img;
	}

	/** charge $_FILES['imgfile'] et archive */
	function loadImage($imgfile,$name){
		ct::dbg("loadImage $imgfile $name");
		$thiss->img=$this->preloadImage($imgfile);
		if(!$thiss->img) return false;
		//$thiss->dir=$this->userdir($name);
		//$thiss->dir=$this->userpath($name);
		
		//$thiss->org=$thiss->dir.$name.".".$thiss->img->type;
		//ct::dbg($thiss->dir);
		//@unlink($thiss->org);
		
		
		$sha_tmp=strrev($name)."000";
		$path=$sha_tmp[0]."/".$sha_tmp[1]."/".$sha_tmp[2]."/";
		
		$file = $thiss->img->tmp;
		$postData = array (
					  'version'=>"1.0",
					  'drop_name'=>$name."_org.".$thiss->img->type,
					  'drop_dir'=>"$path",
					  'file'=>"@$file");
		
		//ct::dbg($postData);
		/*$postData[ 'file' ] = '@'.$file;*/
		
		//$XPost = file_get_contents($thiss->img->tmp);
		//$postData[ 'submit' ] = "UPLOAD";
		
		$url=Constants::httpMedia.'post_userbank/';
		
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_VERBOSE, 1); 
		curl_setopt($ch, CURLOPT_URL, $url );
		//curl_setopt($ch, CURLOPT_UPLOAD, 1); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1 );
		curl_setopt ($ch, CURLOPT_POSTFIELDS, $postData); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, Array('Expect: '));
		//curl_setopt($ch, CURLOPT_HEADER, 1); 
		//seems no need to tell it enctype='multipart/data' it already knows
		//curl_setopt($ch, CURLOPT_POSTFIELDS, $postData );
		
		$response = curl_exec( $ch );
		$http_code = curl_getinfo($ch ,CURLINFO_HTTP_CODE); 
		ct::dbg('curl>'.$postData[ 'drop_name' ].'('.filesize($thiss->img->tmp).') => '.$http_code.'['.$response.']');
		
		$r = split(':',$response);
		//print_r($r);
		if($http_code == 200 && $r[0]=='1')
			return $thiss;
		else
		{
			ct::dbg("loadImage failed $http_code $response");
			$this->error = $response;
			return false;
		}
		/*
		if(copy($thiss->img->tmp,$thiss->org)){
			return $thiss;
		}else{
			$this->error="Copie depuis ".$thiss->img->tmp." vers ".$thiss->org." impossible";
			ct::dbg($this->error);
			return false;
		}*/
	}
	
	/** Archivage et cr�ation des vignettes */
	function loadthumb($imgfile,$name){
		ct::dbg("loadthumb $imgfile $name");
		$img=$this->loadImage($imgfile,$name);
		if(!$img) return false;
		/*
		//Square
		$this->mode="centre";
		$square=$img->dir.$name."_120_120.jpg";
		if(!$this->resizeImage($img->org,$square,120,120)) return false;
		//Original
		$this->mode="tojpeg";
		$org=$img->dir.$name."_org.jpg";
		if(!$this->resizeImage($img->org,$org)) return false;
		//Vire la source
		@unlink($img->org);
		//Vire autres variations
		$exception=array($name."_120_120.jpg",$name."_org.jpg");
		$this->delthumb($name,$exception);
		*/
		return true;
	}

	/** Retourne chemin vers images */
	function userurl($name){
		$dir=$this->userpath($name);
		$path=str_replace(cozop_image::$userbank,"",$dir);
		$thiss->front=Constants::httpMedia."userbank/".$path.$name."_120_202.jpg";
		$thiss->sidebar=Constants::httpMedia."userbank/".$path.$name."_120_85.jpg";
		$thiss->square=Constants::httpMedia."userbank/".$path.$name."_120_120.jpg";
		$thiss->center=Constants::httpMedia."userbank/".$path.$name."CENTER_200_200.jpg";
		$thiss->org=Constants::httpMedia."userbank/".$path.$name."_org.jpg";
		return $thiss;
	}

	/** Cr�e une vignette � partir d'une image existante */
	function makethumb($imgfile,$target,$w,$h){
		//Image in cache
		if($this->cache&&$this->showJPG($target)){
			return true;
		}
//		$this->mode="";
		if(!$this->resizeImage($imgfile,$target,$w,$h)) return false;
		return $this->showJPG($target);
	}

	/** Efface toutes les images sauf $exception */
	function delthumb($name,$exception){
		$dir=$this->userpath($name);
		if(!is_dir($dir)) return false;
		$d=opendir($dir);
		while(false!==($file=readdir($d))){
			if(is_file($dir.$file)&&!in_array($file,$exception)){
				if(@supFile($dir.$file)) $deleted[]=$file;
			}
        }
		closedir($d);
		return $deleted;
	}

	/** nom pour imagedepot */
	function reformatimagename($urlit,$x,$y,$org=false){
		//ct::dbg("reformatimagename","x = $x, y = $y");
		$urlit=ct::outHTTP($urlit);
		$urlit=str_replace("/home/cozop/media/umedia/","media.cozop.com/umedia/",$urlit);		
		$urlit=urlencode($urlit);
 		$urlit=str_replace("__",".....",$urlit);
		$urlit=str_replace("%","__",$urlit);
		if(strlen($urlit)>200) $urlit=substr($urlit,0,200);
		$img=$x."_".$y."_";
		if($org) $img.="org_";
		return $img.$urlit.".jpg";
	}

	static function unformatimagename($urlit){
		list($path,$depot,$p2,$p3,$p4,$u->id,$u->url)=explode("/",ct::outHTTP($urlit));
		//ct::dbg($u->url);
		//print_r($u);
		list($u->x,$u->y,$org)=explode("_",$u->url);
		if(empty($u->id) || empty($u->url)) return false;
		$u->path=$p2."/".$p3."/".$p4."/".$u->id."/";
		//echo $u->path;
		if($org=="org"){
			$u->org=true;
			$u->url=str_replace($u->x."_".$u->y."_org_","",$u->url);
		}else{
			$u->org=false;
			$u->url=str_replace($u->x."_".$u->y."_","",$u->url);
		}
		$u->url=substr($u->url,0,strlen($u->url)-4);
		$u->url=str_replace("__","%",$u->url);
 		$u->url=str_replace(".....","__",$u->url);
		$u->url=urldecode($u->url);
		//ct::dbg($u->url);
		//print_r($u);
		//echo $u->url;
		return $u;
	}
	
	/** Sauvegarde les images URL dans le nom pour repartir � la source en cas de bug */
	function putindepot($id,$urli,$org=false,$ititle='',$ialt='')
	{
		//ct::dbg("putindepot org=".($org?'1':'0'),$urli);
		if(in_array($urli,cozop_image::$bad_images))
		{
			$this->error="banned image";
			//ct::dbg($this->error);
			return false;
		}
		//ct::backtrace();
		$img->i0="";
		if(eregi("static.cozop.com/imgdepot/",$urli)){
			if($u=$this->unformatimagename($urli)){
				$img->i0=$u->url;
				$img->x=$u->x;
				$img->y=$u->y;
				return $img;
			}else{
				$this->error="PB recursion";
				ct::dbg($this->error);
				return false;
			}
		}elseif(eregi("static.cozop.com/umedia/",$urli)){
			//Image initiali in cozop
			$urli=str_replace("static.cozop.com/umedia/","/home/cozop/media/umedia/",ct::outHTTP($urli));	
		}else{
			//Image externe
			$urli=ct::testHTTP($urli);
//			ct::echof($urli);
		}
		//ct::dbg("putindepot get_size ...");
		$img->size=$this->get_size($urli);
		if($img->size->x==0){
			$this->error="Impossible to get image size ".$urli;
			//ct::dbg("putindepot $this->error");
		
			return false;
		}
//		ct::dump($img);
		//ct::dbg("putindepot depotdir ...");
		
		
		//ct::dbg("putindepot img princ. ...");
		
		//Image principale
		if($img->size->x<Constants::minDepotImageX || 
			$img->size->y<Constants::minDepotImageY)
		{//taille mini en une bas
			$this->error="Too small ( ".$img->size->x." x ".$img->size->y." ) : $urli";
			cozop_image::$bad_images[] = $urli;
			//ct::dbg("putindepot $this->error");
			return false;
		}
		//elseif($img->size->x>550){// flo 28/12/08> �tait � 450, on ne downsample pas si possible
			
			//Resize 550
			//flo 26/01/09 comment� : on ne downsample pas l'image on a la place ... on se charge du retaillage 
			//$img->size->y=floor($img->size->y*550/$img->size->x);
			//$img->size->x=550;
		//}
//		ct::dump($img);
		//ct::dbg("putindepot reformatimagename ...");
		
		
		
		if($org)// ajout de l'image sur le serveur statique, methode REST
		{
			return $this->putindepot_v2($id,$img,$urli,$ititle,$ialt);
		}
		
		$path=$this->depotdir($id);
		
		//ct::dbg("path = : ".$path->dir);
		if(!@file_exists($path->dir)){
			if(!FileManager::mkDossier($path->dir)){
				$this->error="Impossible to create dir : $path->dir";
				ct::dbg("putindepot $this->error");
				return false;		
			}
		}
		
		$target=$this->reformatimagename($urli,$img->size->x,$img->size->y,$org);
		
		//ct::dbg("putindepot resizeImage ...");
		
		if(!$this->resizeImage($urli,$path->dir.$target)){
			$this->error="Impossible to resize $urli to ".$img->size->x."/".$img->size->y;
			ct::dbg("putindepot $this->error");
			return false;
		}
		$img->i0=$path->baseurl.$target;
		
		/*if($org)
		{
			//flo 23/01/09 on retaille pour les tailles classiques d'affichages dans cozop
			$target=$this->reformatimagename($urli,Constants::frontBottomImageX,Constants::frontBottomImageY,false);
			$this->resizeImage($urli,$path->dir.$target,Constants::frontBottomImageX,Constants::frontBottomImageY);
			$target=$this->reformatimagename($urli,Constants::sidebarImgX,Constants::sidebarImgY,false);
			$this->resizeImage($urli,$path->dir.$target,Constants::sidebarImgX,Constants::sidebarImgY);
			//$ic->oneindepot($post->id,$imgt->i0,Constants::frontBottomImageX,Constants::frontBottomImageY);
			//$ic->oneindepot($post->id,$imgt->i0,Constants::sidebarImgX,Constants::sidebarImgY);
					
		}*/
		//ct::dbg("putindepot ok ...");
		
		return $img;		
	}

	
	function putindepot_v2($id,$img,$urli,$ititle='',$ialt='')
	{
		//ct::dbg("adding image id $id url $urli ...");
		$img->key = md5('coZop|'.urldecode($urli));
		
		
		$prev = Cache::getImageInfos($img->key);//deja dans le cache
		
		
		
		$img_request = Constants::httpMedia."gen/?key=".$img->key."&url=".urlencode($urli);
		
		//ct::dbg("static img_request: $img_request");
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $img_request);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$output = curl_exec($ch);
		$info = curl_getinfo($ch);
		//ct::dbg($output);
		//ct::dbg($info);
		curl_close($ch);
		
		//ct::dbg("image infos : ");
		//ct::dbg($img);
		
		if(!isset($img->size))
		{
			if(!$infos = getimagesize($urli))
			{
				ct::dbg("getimagesize failed for : $urli");
				return false;
			}
			$img->size->x = $infos[0];
			$img->size->y = $infos[1];
		}
		
		if('1'==$output[0] && $info['http_code']==200)
		{
			$img->i0 = substr($output,2);// reponse type 1:url
			//ct::dbg("static url : ".$img->i0);
			if(!$prev)
			{
				$q = "INSERT INTO images (ikey,org_url,org_x,org_y,fid,org_title,org_alt,ts) VALUES ".
					"('$img->key','".cozop_mysql::mysql_real_escape_string($urli)."',".
						$img->size->x.",".$img->size->y.",".$id.",'".cozop_mysql::mysql_real_escape_string($ititle).
						"','".cozop_mysql::mysql_real_escape_string($ialt)."',NOW())";
				cozop_mysql::mysql_query($q);
			}
			return $img;
		}
		else
		{
			ct::dbg("static server response : [$output] (".$info['http_code'].")");
			return false;
		}
		
	}
	
	/** Regen�re une image du depot */
	function oneindepot($id,$urli,$x,$y,$org=false,$recursif=true){
		$debug=false;
		echo "oneindepot $urli";
		
		//ct::dbg("oneindepot",$urli);
		if($debug&&$_SERVER['REMOTE_ADDR']=='82.238.237.6'){
			ct::echof("$id $urli $x $y");
		}
		
		$path=$this->depotdir($id);
		//print_r($path);
		$file=$path->dir.$this->reformatimagename($urli,$x,$y,$org);
		if($source=$this->findindepot($path->dir,$urli)){
			//Image source in depot
			if($debug&&$_SERVER['REMOTE_ADDR']=='82.238.237.6'){
				ct::echof($file);
				ct::dump($source);exit;
			}
			
			if(!$this->resizeImage($source->file,$file,$x,$y)){
				$this->error="Impossible to resize $urli to ".$x."/".$y." (dir:$path->dir) (1)";
				return false;
			}
			
			return $file;
		}
		
			
		//Ne passe l� que si original d�truit
		if($this->putindepot($id,$urli,true)&&$recursif)
			$this->oneindepot($id,$urli,$x,$y,$org,false);
		else{
			$this->error="Impossible to resize $urli to ".$x."/".$y." (dir:$path->dir) (2)";
			return false;
		}
		
		return $file;
	}
	
	/** recherche les images correspondant � un url dans le depot */
	function findindepot($dir,$urli){
		$md->pattern=$this->reformatimagename($urli,"#","#",true);
		$fp=new filesmanag;
		if(!$list=$fp->listDirPattern($dir,$md->pattern,"date_asc")){
			$this->error=$fp->error;
			return false;
		}
		$md->x=0;
		$md->y=0;
		$md->img="";
		$md->file="";
		
		//flo 04/01/09 > quand on trouve plusieurs images qui correspondent au pattern, on utilise la plus grande
		$max_md = array(0,0,'');
		foreach($list as $value){
			list($md->x,$md->y)=explode("_",$value);
			$md->file=$dir.$value;
			if ($md->x > $max_md[0])
			{
				$max_md = array($md->x,$md->y,$md->file);
			}
		}
		if ($max_md[0]>0)
		{
			list($md->x,$md->y,$md->file) = $max_md;
			return $md;
		}
		$this->error="No image like $md->pattern";
		return false;
	}

	/** indique si une image est externe */
	static function isimagedepot($img,$x="",$y="",$force = false) // force si on veut obligatoirement retailler
	{
		//ct::dbg("isimagedepot [$x] [$y] $img");
		if(eregi("static.cozop.com/imgdepot2/",$img))
		{
			$thiss->version = 2;//depot version
			$elements = split('/',$img);
			$ecount = count($elements);
			$filename = $elements[$ecount-1];
			list($thiss->key,$thiss->ext) = split('\.',$filename);
			$thiss->path = Constants::httpMedia.'imgdepot2/'.$elements[$ecount-4].'/'.$elements[$ecount-3].'/'.$elements[$ecount-2].'/';
			$thiss->fullpath = $thiss->path.$thiss->key;
			//ct::dbg("isimagedepot $img $x $y");
			
			$imginfos = Cache::getImageInfos($thiss->key);
			$x = intval($x);
			$y = intval($y);
			
			if($x>0 && $y==0)//retaillage proportionnel demand�
			{
				$r = $imginfos->org_x/$imginfos->org_y;
				$y = intval($x/$r);
				//ct::dbg("isimagedepot only x, y = $y");
				
			}
			
			if($x==0 && $y==0)//pas de retaillage demnd�
			{
				if( $imginfos )
				{
					$thiss->x=$imginfos->org_x;
					$thiss->y=$imginfos->org_y;
				}
				else
				{
					//ct::dbg("image key ".$thiss->key." not found");
					$thiss->x=-1;
					$thiss->y=-1;
				}
			}
			else
			{
				
				if(	($x<=$imginfos->org_x 
					&& $y<=$imginfos->org_y) || $force)// si on demande plus petit que l'original
				{
					//echo "imgdepot A";
					$thiss->x=intval($x);
					$thiss->y=intval($y);
					$thiss->fullpath .= '_'.$x.'_'.$y;
				}
				else// sinon on renvoie l'original
				{
					//echo "imgdepot B ";
					$thiss->x=$imginfos->org_x;
					$thiss->y=$imginfos->org_y;
				}
			}
			//ct::dbg($img);
			//ct::dbg($thiss->key);
			
			//if(intval($x)>0 && intval($y)>0)
				
			$thiss->fullpath .= '.'.$thiss->ext;
			
			$thiss->link="/_imagekey/".$thiss->key;//todo
			
			
			$thiss->newfile = $thiss->fullpath;//compatibilit� v1
			$thiss->file = $thiss->fullpath;
			$thiss->orgfile = $thiss->path.$thiss->key.'.'.$thiss->ext;
			/*if(!is_object($img))
				$thiss->file=ct::testHTTP($img);//compatibilit� v1
			else
				$thiss->file=$img->file;*/
			//ct::dbg($thiss->path);
			return $thiss;
		}
		if(!eregi("static.cozop.com/imgdepot/",$img) &&
			!eregi("media.cozop.com/imgdepot/",$img)) return false;
		$u=cozop_image::unformatimagename($img);
		$thiss->version = 1;//depot version
		$thiss->path=$u->path;
		$thiss->ox=$u->x;
		$thiss->oy=$u->y;
		$thiss->x=$u->x;
		$thiss->y=$u->y;
		$thiss->file=ct::testHTTP($img);
		$thiss->org=ct::testHTTP($u->url);
		$thiss->link="/_image/".$u->url;
		if($thiss->x<100)
			$thiss->class="small";
		elseif($thiss->x>400)
			$thiss->class="bigimg";
		else
			$thiss->class="medium";

		//New file
		if(!empty($x)&&!empty($y)){
			if($u->org){
				$thiss->newfile=ct::testHTTP(str_replace("/".$thiss->x."_".$thiss->y."_org_","/".$x."_".$y."_",$img));
			}else{
				$thiss->newfile=ct::testHTTP(str_replace("/".$thiss->x."_".$thiss->y."_","/".$x."_".$y."_",$img));
			}
		}else{
			$thiss->newfile="";
		}
			
		return $thiss;
	}
	
	/** ne garde que les images sources */
	static function cleanimagedepot(){
		require_once 'files.class.php';
		$file=new filesmanag;
		$file->purgeDirPattern("/home/cozop/media/imgdepot/","!#_#_org_*");
	}
	
}
