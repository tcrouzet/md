<?php
if(!empty($_POST)) extract($_POST);
if(!empty($_GET)) extract($_GET);
define('WP_EPUB_URL',$baseurl.'/wp-content/plugins/wp2epub/');
define('WP_EPUB_DOWNLOAD',$baseurl.'/wp-content/epub/');

/** liste file par alpha ou date_desc, date_asc */
function listDirPattern($dirname,$pattern,$sort=""){
	if($dirname[strlen($dirname)-1]!='\\') $dirname.='';
	$handle=opendir($dirname);
	if(!$handle){
		$this->error="Dir does not exist";
		return false;
	}
	$result_array=array();
	$pattern=str_replace(array("\*","\?","#"),array(".*",".","[0-9]+"),preg_quote($pattern));
	while(false!==($file=readdir($handle))){
		if(($file==".")||($file=="..")) continue;
		if(!ereg("^".$pattern."$",$file)) continue;
		if(eregi("date",$sort)){
			$date=filemtime($dirname.$file);
			$result_array[$date]=$file;
		}else{
			$result_array[]=$file;
		}
	}
	if(eregi("date_desc",$sort)){
		krsort($result_array);
	}elseif(eregi("date_asc",$sort)){
		ksort($result_array);
	}elseif(empty($sort))
		sort($result_array);
	else
		arsort($result_array);
	closedir($handle);
	return $result_array;
}

function outHTTP($ad) {
	return ereg_replace('http://','',$ad);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<title>eBook Lib</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone')||strstr($_SERVER['HTTP_USER_AGENT'],'iPod')){
	echo('<link rel="stylesheet" href="'.WP_EPUB_URL.'css/handheld.css" type="text/css" media="screen" />');
	$protocolepub="epub";
}else{
	echo('<link rel="stylesheet" href="'.WP_EPUB_URL.'css/style.css" type="text/css" media="screen" />');
	echo('<link rel="stylesheet" href="'.WP_EPUB_URL.'/css/handheld.css" type="text/css" media="handheld" />');
	$protocolepub="http";
}

$epubs=listDirPattern($abspath,"*.epub");

$file=@file_get_contents($abspath."log.txt");
if(!empty($file)){
	
	 $idsmall=substr_count($file,'idsmall.epub'); 
	 $croisadesmall=substr_count($file,'croisadesmall.epub'); 
	 $cinqth=substr_count($file,'5th.epub');
	 $genius=substr_count($file,'genius.epub');
	 $peuple=substr_count($file,'peuple.epub');
	 $ea=substr_count($file,'ea.epub');
	 //	 $epaper=substr_count($file,'epaper.epub'); 
}
?>
</head>
<body>
<div id="center">

<p><a href="<?=$baseurl?>">Revenir au blog</a></p>

<?php
//print_r($epubs);
if(count($epubs)){
	foreach($epubs as $epub){
		$score="";
		if(!empty($file)){
			$score=substr_count($file,$epub);
		}
		echo '<p><a href="'.$protocolepub."://".outHTTP(WP_EPUB_DOWNLOAD).$epub.'">'.$epub."</a><span class=\"hit\">$score</span></p>\n";
	}
}else{
	echo '<p>Pas d\epub en stock!!!';
}
?>

<p class="note">Notes</p>
<ul>
<li>Sur iPhone, <a href="http://itunes.apple.com/app/stanza/id284956128">installez Stanza</a> avant de cliquer sur les liens ePub.</li>
<li>Sous Windows, Mac OS ou Linux, téléchargez l'ePub et envoyez-le sur un lecteur d'ePub genre <a href="http://www.lexcycle.com/">Stanza</a> ou, mieux, <a href="http://calibre-ebook.com/">Calibre</a> (mon préféré) ou <a href="http://lucidor.org/">Lucidor</a>. Ou sur une liseuse comme le Sony-PRS.</li>
</ul>
</div>
</body>
</html>